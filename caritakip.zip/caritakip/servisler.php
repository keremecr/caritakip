<?php require_once 'class.crud.php';
ob_start();
 ?>

<!DOCTYPE html>


<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Modüller</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
    <script src="assets/js/3.6.1.jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="assets/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </head>

  
  <?php 
  $db=new crud();
  $services=$db->findservices();
  $musteritipleri=$db->read("customer_types");
  ?>

  <body>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    } ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">

          <?php include 'navbar.php'; ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              

              <div class="card">
                <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>

               <?php } ?>
                <h5 class="card-header">Modüllerimiz</h5>
                <?php if($_SESSION['type']=="Admin"){ ?>
                  <h5 class="card-title float-right">
                    <a class="btn btn-sm btn-primary" style="color:white; margin-left: 25px" data-bs-toggle="modal" data-bs-target="#smallModalservisinsert"><i class="fa fa-plus"></i>Modül Ekle</a>
                  </h5>
               <?php } ?>
                  
                
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Modül Adı</th>
                        <th>Müşteri Tipi</th>
                        <th>Ekleyen Kullanıcı</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php foreach($services as $service){ ?>
                        <tr>
                          <td><?php echo $service['service_name']; ?></td>
                          <td><?php echo $service['customer_type_name']; ?></td>
                          <td><?php echo $service['user_name']; ?></td>
                          <?php if($service['service_is_delete']==0){ ?>
                            <td>Aktif</td>
                          <?php  } else{ ?>
                            <td>Pasif</td>
                          <?php } ?>
                          <?php if($_SESSION['type']=="Admin"){ ?>
                            <td>
                              <a class="btn btn-sm btn-primary" data-bs-toggle="modal"  style="color:white;" status="<?php echo $service['service_is_delete']; ?>" service-id="<?php echo $service['service_id']; ?>" data-bs-target="#smallModalservisedit" onclick="getstatus(this)">Düzenle<i class="bi bi-pen"></i></a>
                              
                              <a class="btn btn-sm btn-danger" data-bs-toggle="modal" style="color:white;" service-id="<?php echo $service['service_id']; ?>" data-bs-target="#smallModalservisdelete" onclick="getdeleteid(this)">Sil<i class="bi bi-trash"></i></a>

                              
                            </td>

                         <?php } ?>
                        </tr> 
                     <?php } ?>                         
                        

                        <div class="modal fade" tabindex="-1" id="smallModalservisdelete" role="dialog" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <form action="?pg=delete" method="POST">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title">Uyarı</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" onclick="closingmodal()"  aria-label="Close">
                                        
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <p>Silmek istediğinize emin misiniz?</p>
                                    </div>
                                    <input type="hidden"  name="delete_id" id="deleteservis_id">
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" id="closing" data-bs-dismiss="modal" onclick="closingmodal()">Vazgeç</button>
                                      <button type="submit" class="btn btn-primary">Sil</button>
                                    </div>
                                    </form>
                                  </div>
                                </div>
                              </div>


                      
                    </tbody>
                  </table>

              
                </div>
              </div>

              <div class="modal fade" id="smallModalservisinsert" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-sm" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Modül Ekle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <form action="?pg=insert" method="POST">
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Modul Adı</label>
                                  <input type="text" id="service_name" name="service_name" class="form-control" placeholder="Enter Name" required/>
                                </div>
                              </div>                              
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Tipi</label>
                                  <select class="form-select" name="customer_type" id="customer_type" required>
                                    <?php foreach($musteritipleri as $musteritipi) { ?>
                                        <option value="<?php echo $musteritipi['customer_type_id']; ?>"><?php echo $musteritipi['customer_type_name']; ?></option>
                                   <?php } ?>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>


                      <div class="modal fade" id="smallModalservisedit" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Modül Güncelle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <form action="?pg=update" method="POST">
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Modül Adı</label>
                                  <input type="text" id="servis_editname" name="service_name" class="form-control" placeholder="Enter Name" required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Tipi</label>
                                  <select class="form-select" name="customer_type" id="customertypeeditservice" required>
                                    <?php foreach($musteritipleri as $musteritipi){ ?>
                                        <option value="<?php echo $musteritipi['customer_type_id']; ?>"><?php echo $musteritipi['customer_type_name']; ?></option>
                                    <?php } ?>
                                    
                                  </select>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Status</label>
                                  <select class="form-select" name="service_is_delete" id="statuseditservice" required>
                                    
                                    
                                  </select>
                                </div>
                              </div>                                   
                            </div>
                            <input type="hidden" id="servis_editid" name="service_id">
                            <div class="modal-footer">
                              <button type="button" id="closeupdate" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closingupdate()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>



          
              <!-- Layout Demo -->
              
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>

          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <!-- / Layout wrapper -->



    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    
  </body>

  <?php
    if(isset($_GET['pg'])){
      $pg=$_GET['pg'];
      if($pg=='insert'){
        $service_name=$_POST['service_name'];
        $customer_type=$_POST['customer_type'];
        $db=new crud();
        $sonuc=$db->insertservice($service_name,$customer_type);
        if($sonuc['status']){
          $_SESSION['success_message']="Modül başarıyla kaydedildi.";
          $log_summary = [
                    'post' => $_POST,
                ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> 0,
              'type'     => 'A',
              'method'   => 'POST',
              'title'    => 'Modül Ekleme',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          header('Location: servisler.php');
        }
        else{
          $_SESSION['error_message']="Kayıt başarısız";
          header('Location: servisler.php');
        }
      }
      else if($pg=='update'){
        $service_name=$_POST['service_name'];
        $customer_type=$_POST['customer_type'];
        $status=$_POST['service_is_delete'];
        $id=$_POST['service_id'];
        $db=new crud();
        $sonuc=$db->updateservice($service_name,$customer_type,$status,$id);
        if($sonuc['status']){
          $_SESSION['success_message']="Modül başarıyla güncellendi.";
          $log_summary = [
                    'post' => $_POST,
                ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> 0,
              'type'     => 'U',
              'method'   => 'PUT',
              'title'    => 'Modül GÜNCELLEME',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          header('Location: servisler.php');
        }
        else{
          $_SESSION['error_message']="Güncelleme başarısız";
          header('Location: musteritipleri.php');
        }
      }
      else if($pg='delete'){
        $delete_id=$_POST['delete_id'];
        $db=new crud();
        $sonuc=$db->updatestatus("services","service_id","service_is_delete",$id);
        if($sonuc['status']){
          $_SESSION['success_message']="Modül başarıyla silindi.";
          $log_summary = [
                    'post' => $_POST,
                ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> 0,
              'type'     => 'D',
              'method'   => 'DELETE',
              'title'    => 'Modül silme',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          header('Location: servisler.php');
        }
        else{
          $_SESSION['error_message']="Silme başarısız";
          header('Location: servisler.php');
        }
      }
    }



  ?>

</html>
<script src="assets/js/main.js"></script>
<script src="assets/js/ui-toasts.js"></script>

<script>
  function closingmodal(){
    $('#smallModaldelete').modal('toggle');
  }
</script>

<script>
  function getstatus(attr){
    var status=$(attr).attr('status');
    var service_id=$(attr).attr('service-id');
    $('#servis_editid').val(service_id);
    $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{statusserviceedit:status, service_id:service_id},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#servis_editname').val(myArray[0]);
      $('#customertypeeditservice').html(myArray[1]);
      $('#statuseditservice').html(myArray[2]);
    }
  });
  }
  function getdeleteid(attr){
    var service_id=$(attr).attr('service-id');
    $('#deleteservis_id').val(service_id);
  }
</script>



