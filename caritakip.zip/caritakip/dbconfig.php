<?php
define('DBHOST','localhost:3353');
define('DBUSER','test');
define('DBPWD','fx20qz60');
define('DBNAME','panel');
?>