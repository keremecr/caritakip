<?php
session_start();
require_once 'dbconfig.php';

class crud{

    private $db;
    private $dbhost=DBHOST;
    private $dbuser=DBUSER;
    private $dbpass=DBPWD;
    private $dbname=DBNAME;



    function __construct()  {

        try {

            $this->db=new PDO('mysql:host='.$this->dbhost.';dbname='.$this->dbname.';charset=utf8',$this->dbuser,$this->dbpass);

            // echo "Bağlantı Başarılı";

        } catch (Exception $e) {

            die("Bağlantı Başarısız:".$e->getMessage());
        }

    }


    //insert,update gibi metotlarda kolon isimlerini bu fonnksiyona göndeririz her bir kolunun sonuna =? koyup geri gönderir
    public function addValue($argse) {

        $values=implode(',',array_map(function ($item){
            return $item.'=?';
        },array_keys($argse)));

        return $values;
    }
    //--------------------------

    public function sorgu($sorgu){
        $stmt=$this->db->prepare($sorgu);
        $stmt->execute();
        $List = $stmt->fetchAll();
        return $List;
    }
    public function sorgucount($sorgu){
        $stmt=$this->db->prepare($sorgu);
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function sorgukosullu($sorgu,$values=[]){
        $stmt=$this->db->prepare($sorgu);
        $stmt->execute(array_values($values));
        return $stmt;
    }

    public function sorgukosullucount($sorgu,$values=[]){
        $stmt=$this->db->prepare($sorgu);
        $stmt->execute(array_values($values));
        return $stmt->rowCount();
    }


    // herhangi bir tabloda iki koşullu sorgulama yapar
    public function wwread($table,$firstcolumn,$firstvalue,$secondcolumn,$secondvalue){
            $values=['first' => $firstvalue, 'second' => $secondvalue];
            $sql=$this->db->prepare("SELECT * FROM $table WHERE $firstcolumn=? AND $secondcolumn=?");
            $sql->execute(array_values($values));
            return $sql;
    }

    //iki koşullu sorgulamadan kaç tane olduğunu döner.Login işleminde kullandım
    public function wwreadcount($table,$firstcolumn,$firstvalue,$secondcolumn,$secondvalue){
        $values=['first' => $firstvalue, 'second' => $secondvalue];
        $sql=$this->db->prepare("SELECT * FROM $table WHERE $firstcolumn=? AND $secondcolumn=?");
        $sql->execute(array_values($values));
        $count=$sql->rowCount();
        return $count;
    }

    //tek koşullu sorgulamada kaç tane olduğunu döner

    public function wreadcount($table,$column,$deger){
        $veriler=['deger' => $deger];
        $sql=$this->db->prepare("SELECT * FROM $table WHERE $column=?");
        $sql->execute(array_values($veriler));
        $count=$sql->rowCount();
        return $count;
    }

    //üç tabloyu birleştirir 
    public function multiplejoin($firsttable,$secondtable,$thirdtable,$firstcolumn,$secondcolumn){
        $stmt=$this->db->prepare("SELECT * FROM $firsttable a INNER JOIN $secondtable b ON a.$firstcolumn=b.$firstcolumn INNER JOIN $thirdtable c ON a.$secondcolumn=c.$secondcolumn");
        $stmt->execute();
        return $stmt;
    }

    //tabloyu okur

    public function read($table){
        $stmt=$this->db->query("SELECT * FROM $table")->fetchAll();
        return $stmt;
    }

    public function wread($table,$column,$deger){
        $veri=['id' => $deger];
        $stmt=$this->db->prepare("SELECT * FROM $table WHERE $column=?");
        $stmt->execute(array_values($veri));
        return $stmt;
    }

    //girilen mailin var olup olmadığını sorgular
    public function mailquery($email){
        $veri=['mail' => $email];
        $stmt=$this->db->prepare("SELECT * FROM users WHERE email=?");
        $stmt->execute(array_values($veri));
        $count=$stmt->rowCount();
        return $count;
    }

    //
    public function findservicequery($musteritipi,$service){
        if($musteritipi==0 AND $service!=0){
            $veri=['id' => $service, 'customer_service_is_delete' => 0];
            $stmt=$this->db->prepare("SELECT * FROM customer_services h INNER JOIN customer_types t ON h.customer_type_id=t.customer_type_id INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id  WHERE h.service_id=? AND h.customer_service_is_delete=?");
            $stmt->execute(array_values($veri));
            return $stmt;
        }
        else if($musteritipi!=0 AND $service==0){
            $veri=['id' => $musteritipi, 'customer_service_is_delete' => 0];
            $stmt=$this->db->prepare("SELECT * FROM customer_services h INNER JOIN customer_types t ON h.customer_type_id=t.customer_type_id INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id  WHERE h.customer_type_id=? AND h.customer_service_is_delete=?");
            $stmt->execute(array_values($veri));
            return $stmt;
        }
        else{
            $veri=['id' => $musteritipi, 'service_id' => $service, 'customer_service_is_delete' => 0];
            $stmt=$this->db->prepare("SELECT * FROM customer_services h INNER JOIN customer_types t ON h.customer_type_id=t.customer_type_id INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id  WHERE h.customer_type_id=? AND h.service_id=? AND h.customer_service_is_delete=?");
            $stmt->execute(array_values($veri));
            return $stmt;
        }
        
    }


    //servisler sayfasındaki servis bilgilerini gösterir.
    public function findservices(){
        $veri=['is_delete' => 0];
        $stmt=$this->db->prepare("SELECT * FROM services s INNER JOIN customer_types c ON s.customer_type_id=c.customer_type_id INNER JOIN users u ON s.user_id=u.user_id WHERE s.service_is_delete=?");
        $stmt->execute(array_values($veri));
        return $stmt;
    }

    //müşteri tiplerini ekleyen kullanıcıyla birlikte döner
    public function findcustomertypes(){
        $veri=['is_delete' => 0];
        $stmt=$this->db->prepare("SELECT * FROM customer_types c INNER JOIN users u ON c.user_id=u.user_id WHERE c.customer_type_is_delete=?");
        $stmt->execute(array_values($veri));
        return $stmt;
    }

    //kullanıcının silmek istediği veriyi pasife çevirir
    public function updatestatus($table,$column,$statuscolumn,$table_id){
        $veri=['status'=>1, 'table_id' => $table_id];
        try{
            $stmt=$this->db->prepare("UPDATE $table SET $statuscolumn=? WHERE $column=?");
            $stmt->execute(array_values($veri));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }         
    }

    public function updatestatuscservices($values=[]){     

        $customer_id=$values['customer_id'];
        $count=count($values['service_id']);
        $basarilisilme=0;
        $pay_total=0;
        $total=0;
        for($i=1;$i<=$count;$i++){
            $cservice=$this->wwread("customer_services","customer_id",$customer_id,"service_id",$values['service_id'][$i-1]);
            $customer=$this->wread("customers","customer_id",$customer_id);
            foreach($customer as $data){
                $pay_total_tr+=$data['pay_total_tr'];
                $pay_total_usd+=$data['pay_total_usd'];
            }
            foreach($cservice as $item){
                $totaltr+=$item['service_total_tr'];
                $totalusd+=$item['service_total_usd'];
            }
            $veriler=['is_delete' =>1];
            $update=['pay_total_tr' => $pay_total_tr-$totaltr, 'pay_total_usd' => $pay_total_usd-$totalusd];
            try{
                $stmt=$this->db->prepare("UPDATE customer_services SET customer_service_is_delete=? WHERE customer_id=? AND service_id=?");
                $veriler+=['customer_id' => $customer_id, 'service_id' => $values['service_id'][$i-1]];
                $stmt->execute(array_values($veriler));
                $up=$this->db->prepare("UPDATE customers SET {$this->addValue($update)} WHERE customer_id=?");
                $update+=['customer_id' => $values['customer_id']];
                $up->execute(array_values($update));
                $basarilisilme+=1;
            }catch (Exception $e) {
                $basarilisilme=$basarilisilme;
            }   
        }
        if($basarilisilme==$count){
            return ['status' => TRUE];
        }else{
            return ['status' => FALSE];
        }       
    }

    //müşteri tipi ekler
    public function insertcustomertype($musteritipi,$status){
        $user_id=$_SESSION['id'];
        $veriler=['customer_type_name' => $musteritipi, 'customer_type_is_delete' => $status,'user_id' => $user_id];
        try{
            $stmt=$this->db->prepare("INSERT INTO customer_types SET {$this->addValue($veriler)}");
            $stmt->execute(array_values($veriler));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }       
    }

    //müşteri tipi günceller
    public function updatecustomertype($musteritipi,$status,$type_id){
        $user_id=$_SESSION['id'];
        $today=getdate();
        $tarih=$today['year']."-".$today['mon']."-".$today['mday']." ".$today['hours'].":".$today['minutes'].":".$today['seconds'];
        $veriler=['customer_type_name' => $musteritipi, 'customer_type_is_delete' => $status,'user_id' => $user_id, 'customer_type_edit_date' => $tarih];
        try{
            $stmt = $this->db->prepare("UPDATE customer_types SET {$this->addValue($veriler)} WHERE customer_type_id=?");
            $veriler+=['customer_type_id' => $type_id];
            $stmt->execute(array_values($veriler));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }      
    }

    //silme işlemini yapar olur da uçurmak istediğimiz veri olursa diye yazdım  
    public function delete($table,$column,$table_id){
        $veri=['id' => $table_id];
        try{
            $stmt=$this->db->prepare("DELETE FROM $table WHERE $column=?");
            $stmt->execute(array_values($veri));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }        
    }

    //müşteri listesi sayfasında müşterileri listeler.
    public function findcustomers(){
        $veri=['is_delete' => 0];
        $stmt=$this->db->prepare("SELECT * FROM customers c INNER JOIN customer_types t ON c.customer_type_id=t.customer_type_id  INNER JOIN users u ON c.user_id=u.user_id WHERE c.customer_is_delete=?");
        $stmt->execute(array_values($veri));
        return $stmt;
    }

    //müşteri bilgisini günceller
    public function updatecustomer($musteriadi,$customer_typeid,$status,$customer_id){
        $user_id=$_SESSION['id'];
        $today=getdate();
        $tarih=$today['year']."-".$today['mon']."-".$today['mday']." ".$today['hours'].":".$today['minutes'].":".$today['seconds'];
        $veriler=['customer_name' => $musteriadi, 'customer_type_id' => $customer_typeid, 'customer_is_delete'=> $status, 'customer_edit_date' => $tarih];
        $options=['customer_name' => $musteriadi, 'customer_type_id' => $customer_typeid,  'customer_is_delete'=> $status, 'customer_edit_date' => $tarih, 'customer_id' => $customer_id];
        try{
            $stmt = $this->db->prepare("UPDATE customers SET {$this->addValue($veriler)} WHERE customer_id=?");
            $stmt->execute(array_values($options));
            $son=$this->db->lastInsertId();
            return ['status' => TRUE, 'id' => $son];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }  
    }

    //müşteri ekler
    public function insertcustomer($musteriadi,$customer_type_id,$casual_date,$pay_total_tr,$pay_total_usd){
        $casual_date=explode("T",$casual_date);
        $casual_date=$casual_date[0]." ".$casual_date[1];
        $user_id=$_SESSION['id'];
        $veriler=['customer_name' => $musteriadi, 'customer_type_id' => $customer_type_id, 'user_id' => $user_id, 'casual_date' => $casual_date, 'pay_total_tr' => $pay_total_tr, 'pay_total_usd' => $pay_total_usd];       
        try{
            $stmt=$this->db->prepare("INSERT INTO customers SET {$this->addValue($veriler)}");
            $stmt->execute(array_values($veriler));
            $son=$this->db->lastInsertId();
            return [ 'id' => $son, 'status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }       
    }

    //müşteri servislerini gösterir
    public function findcustomerservices(){
        $veri=['is_delete' => 0];
        $stmt=$this->db->prepare("SELECT * ,GROUP_CONCAT(v.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(s.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(s.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(s.service_total SEPARATOR ',') AS servisucret FROM customer_services s INNER JOIN customer_types t ON s.customer_type_id=t.customer_type_id INNER JOIN customers c ON s.customer_id=c.customer_id INNER JOIN users u ON s.user_id=u.user_id INNER JOIN services v ON s.service_id=v.service_id WHERE s.customer_service_is_delete=? GROUP BY c.customer_id ORDER BY s.customer_id");
        $stmt->execute(array_values($veri));
        return $stmt;
    }

    //herhangi bir müşteri servisinin verilerini döner
    public function customerservicebyid($cservice_id){
        $veri=['id' => $cservice_id, 'is_delete' => 0];
        $stmt=$this->db->prepare("SELECT * FROM customer_services s INNER JOIN customer_types t ON s.customer_type_id=t.customer_type_id INNER JOIN customers c ON s.customer_id=c.customer_id INNER JOIN users u ON s.user_id=u.user_id INNER JOIN services v ON s.service_id=v.service_id WHERE s.customer_service_id=? AND s.customer_service_is_delete=?");
        $stmt->execute(array_values($veri));
        return $stmt;
    }

    //herhangi bir müşterinin aldığı servisleri döner müşteri id si parametre olarak verilir
    public function customerservicebycustomerid($customer_id){
        $veri=['id' => $customer_id, 'is_delete' => 0, 'cis' => 0];
        $stmt=$this->db->prepare("SELECT * FROM customer_services s INNER JOIN customer_types t ON s.customer_type_id=t.customer_type_id INNER JOIN customers c ON s.customer_id=c.customer_id INNER JOIN users u ON s.user_id=u.user_id INNER JOIN services v ON s.service_id=v.service_id WHERE s.customer_id=? AND s.customer_service_is_delete=? AND c.customer_is_delete=?");
        $stmt->execute(array_values($veri));
        return $stmt;
    }

    //müşteri servisi ekler.Kullanıcının istediği servisleri istediği müşteriye ekler, eklenecek servisler dizi şeklinde gelir bu yüzden döngü içinde insert basıldı
    public function insertcustomerservice($values=[]){
        $eklenecekadet=$values['inputsayisi'];
        $user_id=$_SESSION['id'];
        $customer=$this->wread("customers","customer_id",$values['customer_id']);
        foreach($customer as $item){
            $customer_type_id=$item['customer_type_id'];
            $pay_total_tr=$item['pay_total_tr'];
            $pay_total_usd=$item['pay_total_usd'];
            $customer_name=$item['customer_name'];
        }
        $basarilikayit=0;
        $index=0;
        $values+=['customer_name' => $customer_name];
        for($i=1;$i<=$eklenecekadet;$i++){
            $service=$this->wread("services","service_id",$values['service_name'][$index]);
            foreach($service as $item){
                $values+=['service_name_'.$i.'' => $item['service_name']];
            }
             $veriler=['service_id' => $values['service_name'][$index], 'customer_type_id' => $customer_type_id, 'customer_id' => $values['customer_id'],  'user_id' => $user_id, 'quantity' => $values['adet_'.$i], 'service_total_tr' =>$values['total_tr_'.$i], 'service_total_usd' =>$values['total_usd_'.$i]];
             $update=['pay_total_tr' => $pay_total_tr + $values['total_tr_'.$i], 'pay_total_usd' => $pay_total_usd + $values['total_usd_'.$i]];
             try{
                $stmt=$this->db->prepare("INSERT INTO customer_services SET {$this->addValue($veriler)}");
                $stmt->execute(array_values($veriler));
                $up=$this->db->prepare("UPDATE customers SET {$this->addValue($update)} WHERE customer_id=?");
                $update+=['customer_id' => $values['customer_id']];
                $up->execute(array_values($update));
                $son=$this->db->lastInsertId();
                ///////////////////////
                $log_summary = [
                    'post' => $values,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> $values['customer_id'],
                    'type'     => 'A',
                    'method'   => 'POST',
                    'title'    => 'Müşteriye Modül Ekleme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $this->log($user_log);
                /////////////////////////
                $basarilikayit+=1;
             }catch (Exception $e){
                $basarilikayit=$basarilikayit;
             }
            $index+=1;           
        }
        if($basarilikayit==$eklenecekadet){           
            return ['status' => TRUE];
        }
        else{
            return ['status' => FALSE];
        }       
    }


    //müşteri servisini id vererek güncelliyoruz dasboard.php 265.satırda bu fonksiyonu çağırdım
    public function updatecservicebyid($cservice_id,$values=[]){
        $veriler=['quantity' => $values['quantity'], 'customer_service_is_delete' => $values['is_delete']];
        try{
            $stmt=$this->db->prepare("UPDATE customer_services SET {$this->addValue($veriler)} WHERE customer_service_id=?");
            $veriler+=['customer_service_id' => $cservice_id];
            $stmt->execute(array_values($veriler));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }     
    }

    //müşteri servisini günceller müşterinin servislerinde en son girilen değerleri yerine koyar
    public function updatecustomerservice($values=[]){
        $inputsayisi=$values['inputsayisi']-1;
        $user_id=$_SESSION['id'];
        $today=getdate();
        $tarih=$today['year']."-".$today['mon']."-".$today['mday']." ".$today['hours'].":".$today['minutes'].":".$today['seconds'];
        $basarilikayit=0;
        $customer=$this->wread("customers","customer_id",$values['customer_id']);
        foreach($customer as $item){
            $customer_type_id=$item['customer_type_id'];
            $pay_total_tr=$item['pay_total_tr'];
            $pay_total_usd=$item['pay_total_usd'];
        }
        $cservices=$this->wread("customer_services","customer_id",$values['customer_id']);
        $stotalstr=0;
        $stotalsusd=0;
        foreach($cservices as $cservice){
            $stotalstr+=$cservice['service_total_tr'];
            $stotalsusd+=$cservice['service_total_usd'];
        }
        for($i=1;$i<=$inputsayisi;$i++){
            $yenitr+=$pay_total_tr-$stotalstr+$values['total_tr_'.$i];
            $yeniusd+=$pay_total_usd-$stotalsusd+$values['total_usd_'.$i];
            $veriler=['customer_service_is_delete' => $values['status_'.$i], 'quantity' => $values['adet_'.$i], 'cservice_edit_date' => $tarih, 'service_total_tr' => $values['total_tr_'.$i], 'service_total_usd' => $values['total_usd_'.$i]];
            $update=['pay_total_tr' => $yenitr, 'pay_total_usd' => $yeniusd];
            try{
                $stmt = $this->db->prepare("UPDATE customer_services SET {$this->addValue($veriler)} WHERE customer_id=? AND service_id=?");
                $veriler+=['customer_id' => $values['customer_id'], 'service_id' => $values['service_id_'.$i]];
                $stmt->execute(array_values($veriler));
                $up=$this->db->prepare("UPDATE customers SET {$this->addValue($update)} WHERE customer_id=?");
                $update+=['customer_id' => $values['customer_id']];
                $up->execute(array_values($update));
                ///////////////////////
                $log_summary = [
                    'post' => $values,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> $values['customer_id'],
                    'type'     => 'U',
                    'method'   => 'PUT',
                    'title'    => 'Müşteri Modül Güncelleme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $this->log($user_log);
                /////////////////////////
                $basarilikayit+=1;
            }catch (Exception $e) {
                $basarilikayit=$basarilikayit;
            }              
        }
        if($basarilikayit==$inputsayisi){           
            return ['status' => TRUE];
        }
        else{
            return ['status' => FALSE];
        } 
    }

    //müşteri servisini siler olur da uçurmak istediğimiz bi servis olursa diye yazdım

    public function deletecustomerservice($values=[]){
        $customer_id=$values['customer_id'];
        $count=count($_POST['service_id']);
        $basarilisilme=0;
        $pay_total=0;
        $total=0;
        for($i=1;$i<=$count;$i++){
            $cservice=$this->wwread("customer_services","customer_id",$customer_id,"service_id",$values['service_id'][$i-1]);
            $customer=$this->wread("customers","customer_id",$customer_id);
            foreach($customer as $data){
                $pay_total_tr+=$data['pay_total_tr'];
                $pay_total_usd+=$data['pay_total_usd'];
            }
            foreach($cservice as $item){
                $totaltr+=$item['service_total_tr'];
                $totalusd+=$item['service_total_usd'];
            }
            $yenitr=$pay_total_tr-$totaltr;
            echo $yenitr;
            continue;
            /*
            $yeniusd=$pay_total_usd-$totalusd;
            $veriler=['customer_id' => $customer_id, 'service_id' => $values['service_id'][$i-1]];
            $update=['pay_total_tr' => $yenitr, 'pay_total_usd' => $yeniusd];
            try{
                $stmt=$this->db->prepare("DELETE FROM customer_services WHERE customer_id=? AND service_id=?");
                $stmt->execute(array_values($veriler));
                $up=$this->db->prepare("UPDATE customers SET {$this->addValue($update)} WHERE customer_id=?");
                $update+=['customer_id' => $values['customer_id']];
                $up->execute(array_values($update));
                $basarilisilme+=1;
            }catch (Exception $e) {
                $basarilisilme=$basarilisilme;
            }*/
            
        }
    }

    //servis ekler

    public function insertservice($service_name,$customer_type){
        $user_id=$_SESSION['id'];
        $veriler=['service_name' => $service_name, 'customer_type_id' => $customer_type, 'user_id' => $user_id];
        try{
            $stmt = $this->db->prepare("INSERT INTO services SET {$this->addValue($veriler)}");
            $stmt->execute(array_values($veriler));
            $son=$this->db->lastInsertId();
            return ['status' => TRUE, 'id' => $son];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }  
    }

    //servis bilgisini günceller.Online takip,RDP gibi (müşteri servisleri değil)

    public function updateservice($service_name,$customer_type,$status,$service_id){
        $user_id=$_SESSION['id'];
        $veriler=['service_name' => $service_name, 'customer_type_id' => $customer_type, 'user_id' => $user_id, 'service_is_delete'=> $status];
        try{
            $stmt = $this->db->prepare("UPDATE services SET {$this->addValue($veriler)} WHERE service_id=?");
            $veriler+=['service_id' => $service_id];
            $stmt->execute(array_values($veriler));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }  
    }

    //müşteri servisleri sayfasında inputa sadece servis bilgisi girildiği zaman çalışacak olan fonksiyon

    public function findcustomerservicesbyservice($servis){
        $veri=['id' => $servis, 'is_delete' => 0];
        $stmt=$this->db->prepare("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total SEPARATOR ',') AS servisucret FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE h.service_id=? AND h.customer_service_is_delete=? GROUP BY h.customer_service_id");
        $stmt->execute(array_values($veri));
        return $stmt;       
    }

    //müşteri servisleri sayfasında inputa sadece müşteri bilgisi girildiği zaman çalışacak olan fonksiyon 
    public function findcustomerservicesbycustomer($musteri){
        $veri=['musteri' => "%$musteri%", 'is_delete' => 0];
        $stmt=$this->db->prepare("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total SEPARATOR ',') AS servisucret FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE c.customer_name LIKE ? AND h.customer_service_is_delete=? GROUP BY c.customer_id");
        $stmt->execute(array_values($veri));
        return $stmt;       
    }

    //müşterinin kendisine ait servisleri getirir kullanıcı bu servislerin arasından istediğini silebilecek ajax.php 342 de çağırıyorum

    public function findcustomerservicesbycustomerid($customer_id){
        $veri=['musteri' => $customer_id, 'is_delete' => 0];
        $stmt=$this->db->prepare("SELECT * FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE h.customer_id=? AND h.customer_service_is_delete=?");
        $stmt->execute(array_values($veri));
        return $stmt;       
    }

    //müsteriservisleri.php de live search de hem müşteri hem de servis inputuna veri girerse çalışacak olan fonksiyon
    public function findcustomerservicesbyboth($musteri,$servis){
        $veri=['musteri' => "%$musteri%", 'id' => $servis, 'cis' => 0];
        $stmt=$this->db->prepare("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total SEPARATOR ',') AS servisucret FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE c.customer_name LIKE ? AND h.service_id=? AND h.customer_service_is_delete=? GROUP BY c.customer_id, s.service_id");
        $stmt->execute(array_values($veri));
        return $stmt;       
    }

    //sql injection engelleme
    public function db_escape($value){
        $value = str_replace('%', '\%%', $value);
        $replace_text = 
        [
            'SELECT', 'INSERT', 'DROP', 'REPLACE', 'FROM', 'UNION', 'WHERE', 'JOIN', 'ALTER', 'SLEEP', ' AND ', " OR ", // '=', ';', '\'', '\/', '"',
        ];
        $value = str_ireplace($replace_text, ' ', $value);
        return $value;
    }

    //sorgunun türüne göre sorgu
    public function select_query($sql, $select='all'){
        if ($select=="all") {
            $sql = $this->db->query($sql)->fetchAll();
        }elseif($select=="one"){
            $sql = $this->db->query($sql)->fetch(PDO::FETCH_ASSOC);
        }elseif ($select=="add") {
            $sql = $this->db->query($sql);
        }
        return $sql;
    }

    //burada log basılıyor
    public function log($data){
       


        $data->customer_id = isset($data->customer_id) ? $data->customer_id : 0;
        $data->user_id = isset($data->user_id) ? $data->user_id : 0;

        ////////////////////////////////////////////////////////
        // yeni loglama sistemi
        $title_id = $this->select_query("SELECT id FROM action_logs_titles WHERE title_name = '".$this->db_escape($data->title)."' LIMIT 1", "one");
        if (empty($title_id['id'])) {
            $this->select_query("INSERT INTO action_logs_titles SET title_name = '".mb_substr(trim($this->db_escape($data->title)), 0, 50)."'", "add");
            $title_id = $this->select_query("SELECT id FROM action_logs_titles WHERE title_name = '".mb_substr($this->db_escape($data->title), 0, 50)."' LIMIT 1", "one");
            $title_id = $title_id['id'];
        }else{
            $title_id = $title_id['id'];
        }
        $type_options = array(
            'A' => 'Ekleme',
            'U' => 'Düzenleme',
            'D' => 'Silme',
            'R' => 'Raporlama',
            'O' => 'Diğer'
        );
        $type_id = $this->select_query("SELECT id FROM action_logs_types WHERE type_name = '".trim($this->db_escape($type_options[$data->type]))."' AND type = 1 LIMIT 1", "one");
        if (empty($type_id['id'])) {
            $this->select_query("INSERT INTO action_logs_types SET type_name = '".trim($this->db_escape($type_options[$data->type]))."', type = 1", "add");
            $type_id = $this->select_query("SELECT id FROM action_logs_types WHERE type_name = '".trim($this->db_escape($type_options[$data->type]))."' AND type = 1 LIMIT 1", "one");
            $type_id = $type_id['id'];
        }else{
            $type_id = $type_id['id'];
        }
        $method_options = array(
            'DELETE' => 'DELETE',
            'GET' => 'GET',
            'POST' => 'POST',
            'PUT' => 'PUT',
            'UPDATE' => 'UPDATE',
            'XML' => 'XML',
        );
        $response_opt = array(
            'ok' => 'Başarılı',
            'error' => 'Hatalı'
        );    
        $method_id = $this->select_query("SELECT id FROM action_logs_types WHERE type_name = '".trim($this->db_escape($method_options[$data->method]))."' AND type = 3 LIMIT 1", "one");
        if (empty($method_id['id'])) {
            $this->select_query("INSERT INTO action_logs_types SET type_name = '".trim($this->db_escape($method_options[$data->method]))."', type = 3", "add");
            $method_id = $this->select_query("SELECT id FROM action_logs_types WHERE type_name = '".trim($this->db_escape($method_options[$data->method]))."' AND type = 3 LIMIT 1", "one");
            $method_id = $method_id['id'];
        }else{
            $method_id = $method_id['id'];
        }
        $response = $this->select_query("SELECT id FROM action_logs_types WHERE type_name = '".trim($this->db_escape($response_opt[$data->response]))."' AND type = 2 LIMIT 1", "one");
        if (empty($response['id'])) {
            $this->select_query("INSERT INTO action_logs_types SET type_name = '".trim($this->db_escape($response_opt[$data->response]))."', type = 2", "add");
            $response = $this->select_query("SELECT id FROM action_logs_types WHERE type_name = '".trim($this->db_escape($response_opt[$data->response]))."' AND type = 2 LIMIT 1", "one");
            $response = $response['id'];
        }else{
            $response = $response['id'];
        }
        $ip_id = $this->select_query("SELECT id FROM action_logs_ips WHERE ip = '".trim($this->db_escape($data->ip))."' LIMIT 1", "one");        
        if (empty($ip_id['id'])) {
            $this->select_query("INSERT INTO action_logs_ips SET ip = '".trim($this->db_escape($data->ip))."'", "add");
            $ip_id = $this->select_query("SELECT id FROM action_logs_ips WHERE ip = '".trim($this->db_escape($data->ip))."' LIMIT 1", "one");
            $ip_id = $ip_id['id'];
        }else{
            $ip_id = $ip_id['id'];
        }
        $this->select_query("INSERT INTO `action_logs` (`user_id`, `company_id`, `type_id`, `method_id`, `title_id`, `response`, `summary`, `ip_id`, `add_date`) VALUES (
            '".$data->user_id."', 
            '".$data->company_id."', 
            '".$type_id."', 
            '".$method_id."',
            '".$title_id."',
            '".$response."',
            '".preg_replace('@[\s]{2,}@',' ',str_ireplace(array("'",'\r','\n'), array("\'",'',''), $data->summary))."',
            '".$ip_id."', 
            NOW())", "add");
        return true;
    }

    public function userupdate($values=[],$phone,$name,$isadmin=0){
        if($isadmin){
            $veri=['user_name' => $name, 'email' => $values['email'], 'phone_number' => $phone, 'type' => $values['type']];
        
        }else{
            $veri=['user_name' => $name, 'email' => $values['email'], 'phone_number' => $phone, 'address' => $values['address'], 'country' => $values['country'], 'language' => $values['language'], 'timezone' => $values['timezone'], 'currency' => $values['currency']];
        }
        try{
            $stmt=$this->db->prepare("UPDATE users SET {$this->addValue($veri)} WHERE user_id=?");
            $veri+=['user_id' => $values['user_id']];
            $stmt->execute(array_values($veri));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }  
    }

    public function insertuser($values=[],$phone){
        $veri=['user_name' => $values['user_name'], 'email' => $values['email'], 'phone_number' => $phone, 'type' => $values['type']];
        try{
            $stmt=$this->db->prepare("INSERT INTO users SET {$this->addValue($veri)}");
            $stmt->execute(array_values($veri));
            return ['status' => TRUE];
        }catch (Exception $e) {
            return ['status' => FALSE, 'error' => $e->getMessage()];
        }  
    }
    
}




?>