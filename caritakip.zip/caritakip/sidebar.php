

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="dashboard.php" class="app-brand-link">            
              <span class="app-brand-text demo menu-text fw-bolder ms-2">Ajannet</span>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->

            <!-- Layouts -->
            <li class="menu-item">
              <a  href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div data-i18n="Layouts">Tanımlar</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="musteritipleri.php" class="menu-link">
                    <div data-i18n="Without menu">Müşteri Tipi Tanımları</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="servisler.php" class="menu-link">
                    <div data-i18n="Without menu">Modul Tanımları</div>
                  </a>
                </li>				
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                  <i class="menu-icon tf-icons bx bx-layout"></i>
                  <div data-i18n="Layouts">Kullanıcı İşlemleri</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="accountsettings.php" class="menu-link">
                    <div data-i18n="Without menu">Hesabım</div>
                  </a>
                </li>
              </ul>
              <?php if($_SESSION['type']=="Admin") { ?>
                <ul class="menu-sub">
                <li class="menu-item">
                  <a href="users.php" class="menu-link">
                    <div data-i18n="Without menu">Kullanıcılar</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="hareketler.php" class="menu-link">
                    <div data-i18n="Without menu">Kullanıcı Hareketleri</div>
                  </a>
                </li>
              </ul>
            <?php  } ?>
              
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                  <i class="menu-icon tf-icons bx bx-layout"></i>
                  <div data-i18n="Layouts">Müşteri Carileri</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="musteriler.php" class="menu-link">
                    <div data-i18n="Without menu">Genel Cari</div>
                  </a>
                </li>			  
                <li class="menu-item">
                  <a href="musteriservisleri.php" class="menu-link">
                    <div data-i18n="Without menu">Detaylı Cari</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="dashboard.php?au=logout" class="menu-link">
                  <i class="menu-icon tf-icons bx bx-layout"></i>
                  <div data-i18n="Without menu">Çıkış Yap</div>
              </a>
            </li>
           
            <!-- Components -->
            
        </ul>
</aside>
