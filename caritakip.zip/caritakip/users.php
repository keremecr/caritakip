
<?php require_once 'class.crud.php';
ob_start(); 
?>
<!DOCTYPE html>



<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Kullanıcı Listesi</title>


    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>

    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
    
  </head>

  <?php 
  $db=new crud();
  $users=$db->sorgu("SELECT * FROM users");


  ?>

  <body>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    }else if($_SESSION['type']!="Admin"){
      header('Location: dashboard.php');
    } ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <?php include 'navbar.php'; ?>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Tables /</span>Kullanıcılar</h4>

              <!-- Basic Bootstrap Table -->
              <div class="card">
                <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>

               <?php } ?>
                <h5 class="card-header">Şirketimizin Kullanıcıları</h5>
                <div class="row m-2">
                  <div class="col-md-2">
                          <a class="btn btn-sm btn-primary text-white" data-bs-toggle="modal" data-bs-target="#Modalinsertuser"><i class="fa fa-plus"></i>Kullanıcı Ekle</a>
                  </div>
                </div>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Adı</th>
                        <th>Email</th>
                        <th>Yetki</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php foreach($users as $user) { ?>
                        <tr>
                        <td><i class="fab fa-angular fa-lg text-danger me-3"></i><?php echo $user['user_name']; ?></td>
                        <td><?php echo $user['email']; ?></td>
                        <td>
                          <?php if($user['type']=="Admin"){ ?>
                            Admin
                         <?php }else{ ?>
                            User
                       <?php } ?>
                          
                        </td>
                        <td><span class="badge bg-label-primary me-1">
                          <?php if($user['user_is_delete']==0){ ?>
                            Aktif
                         <?php }else{ ?>
                            Pasif
                       <?php } ?>
                        </span></td>
                        <td>
                          <a class="btn btn-sm btn-primary" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaledituser" id="buton" user-id="<?php echo $user['user_id']; ?>" onclick="getuseredit(this)" >Düzenle<i class="bi bi-pen"></i></a>                                                         

                              <a class="btn btn-sm btn-danger" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaldeleteuser" id="silmebutonu" user-id="<?php echo $user['user_id']; ?>" onclick="getdatadelete(this)">Sil<i class="bi bi-trash"></i></a>
                        </td>
                      </tr>
                    <?php  } ?>
                      
                      
                    </tbody>
                  </table>
                </div>
              </div>
              <!--/ Basic Bootstrap Table -->

              <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
    <div class="modal fade" id="Modalinsertuser" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Kullanıcı Ekle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>

                            <div class="modal-body">
                              <form action="?pg=insert" method="POST">
                                <div class="row">
                                  <div class="col mb-3">
                                    <label for="nameSmall" class="form-label">Kullanıcı Adı</label>
                                    <input class="form-control" type="text" name="user_name" id="name" required/>
                                  </div>
                                </div> 

                              <div class="row">
                                <div class="col mb-12">
                                  <label for="nameSmall" class="form-label">Email Adresi</label>
                                  <input class="form-control" type="email" name="email" id="email" required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-12">
                                  <label for="nameSmall" class="form-label">Telefon</label>
                                  <select class="form-select btn-sm" name="kod" id="kod" onchange="getresults(this)" required>                                                                         
                                    <option value="90" selected>TR +90</option>
                                    <option value="1">US +1</option>                                              
                                  </select>                           
                                  <input
                                    type="text"
                                    id="phoneNumber"
                                    name="phonenumber"
                                    class="form-control"
                                  />
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-12">
                                  <label for="nameSmall" class="form-label">Yetkisi</label>
                                  <select class="form-select btn-sm" name="type" id="type" required>                                                                         
                                    <option value="Admin" selected>Admin</option>
                                    <option value="User">User</option>                                              
                                  </select>                           
                                </div>
                              </div>
                                                                                               
                            </div>                            
                            <div class="modal-footer">
                              <button type="button" id="closeinsert" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closinginsert()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>

                      <!--kullanıcı düzenleme -->

                      <div class="modal fade" id="Modaledituser" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Kullanıcı Düzenleme</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>

                            <div class="modal-body">
                              <form action="?pg=update" method="POST">
                                <div class="row">
                                  <div class="col mb-3">
                                    <label for="nameSmall" class="form-label">Kullanıcı Adı</label>
                                    <input class="form-control" type="text" name="user_name" id="nameedit" required/>
                                  </div>
                                </div> 

                              <div class="row">
                                <div class="col mb-12">
                                  <label for="nameSmall" class="form-label">Email Adresi</label>
                                  <input class="form-control" type="email" name="email" id="emailedit" required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-12">
                                  <label for="nameSmall" class="form-label">Telefon</label>
                                  <div id="kodedit">
                                    <select class="form-select btn-sm" name="kod" id="kodedit" required>                                                                         
                                      <option value="90" selected>TR +90</option>
                                      <option value="1">US +1</option>                                              
                                    </select>
                                  </div>                           
                                  <input
                                    type="text"
                                    id="phonenumberedit"
                                    name="phonenumber"
                                    class="form-control"
                                  />
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-12">
                                  <label for="nameSmall" class="form-label">Yetkisi</label>
                                  <div id="edittype">
                      
                                  </div>                          
                                </div>
                              </div>
                              
                              <input type="hidden" id="usereditid" name="user_id">                                                                 
                            </div>                            
                            <div class="modal-footer">
                              <button type="button" id="closeinsert" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closinginsert()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>




    

    <!-- Core JS -->
   </body>

   <?php
    if(isset($_GET['pg'])){
      $pg=$_GET['pg'];
      if($pg=='insert'){
        $db=new crud();
        $phone=$_POST['kod']." ".$_POST['phonenumber'];
        $sonuc=$db->insertuser($_POST,$phone);
        if($sonuc['status']){
          $log_summary = [
                    'post' => $_POST,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> 0,
                    'type'     => 'A',
                    'method'   => 'POST',
                    'title'    => 'Kullanıcı Ekleme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $db->log($user_log);
          $_SESSION['success_message']="Kullanıcı başarıyla kaydedildi.";
          header('Location: users.php');
        }
        else{
          $_SESSION['error_message']="Kayıt başarısız";
          header('Location: users.php');
        }
      }
      else if($pg=='update'){
        $db=new crud();
        $name=$_POST['user_name'];
        $phone=$_POST['kod']." ".$_POST['phonenumber'];
        $sonuc=$db->userupdate($_POST,$phone,$name,1);
        if($sonuc['status']){
          $_SESSION['success_message']="Kullanıcı başarıyla güncellendi.";
          $log_summary = [
                    'post' => $_POST,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> 0,
                    'type'     => 'U',
                    'method'   => 'PUT',
                    'title'    => 'Kullanıcı Bilgisi Güncelleme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $db->log($user_log);
          header('Location: users.php');
        }
        else{
          $_SESSION['error_message']="Güncelleme başarısız";
          header('Location: users.php');
        }
      }
      else if($pg=='delete'){
        $db=new crud();
        $sonuc=$db->updatestatus("users","user_id","user_is_delete",$_POST['userdeleteid']);
        if($sonuc['status']){
          $_SESSION['success_message']="Kullanıcı başarıyla silindi.";
          $log_summary = [
                    'post' => $_POST,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> 0,
                    'type'     => 'D',
                    'method'   => 'DELETE',
                    'title'    => 'Kullanıcı silme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $db->log($user_log);
          header('Location: users.php');
        }
        else{
          $_SESSION['error_message']="Silme başarısız";
          header('Location: users.php');
        }
      }
      else if($pg=='temizle'){
        header('Location: users.php');
      }
    }



  ?> <!-- build:js assets/vendor/js/core.js -->
    
</html>


<script>
  function closinginsert(){
  $('#Modalinsertservice').modal('toggle');
  }
  function closingupdate(){
    $('#Modaleditservice').modal('toggle');
  }
  function closingdelete(){
    $('#Modaldeleteservice').modal('toggle');
  }

  function getuseredit(attr){
    var user_id=$(attr).attr('user-id');
    $('#usereditid').val(user_id);
    $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{usereditid:user_id},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#nameedit').val(myArray[0]);
      $('#emailedit').val(myArray[1]);
      $('#kodedit').html(myArray[2]);
      $('#phonenumberedit').val(myArray[3]);
      $('#edittype').html(myArray[4]);
    }
  });

  }

  function getdatadelete(attr){
    var user_id=$(attr).attr('user-id');
  }


</script>









<script src="assets/js/ui-toasts.js"></script>
<script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  