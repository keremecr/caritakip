<?php require_once 'class.crud.php';
ob_start();
 ?>

<!DOCTYPE html>


<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Müşteri Tipleri</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script
      src="https://code.jquery.com/jquery-3.6.0.min.js"
      integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
      crossorigin="anonymous"
    ></script>
  </head>

  
  <?php 
  $db=new crud();
  $musteritipleri=$db->findcustomertypes();
  ?>

  <body>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    } ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <?php include 'navbar.php'; ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              

              <div class="card">
                <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>

               <?php } ?>
                <h5 class="card-header">Müşteri Tipleri</h5>
                <?php if($_SESSION['type']=="Admin"){ ?>
                  <h5 class="card-title float-right">
                    <a class="btn btn-sm btn-primary" style="color:white; margin-left: 25px" data-bs-toggle="modal" data-bs-target="#smallModal"><i class="fa fa-plus"></i>Müşteri Tipi Ekle</a>
                  </h5>
               <?php } ?>
                  
                
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Müşteri Tipi</th>
                        <th>Eklenme Tarihi</th>
                        <th>Ekleyen Kullanıcı</th>
                        <th>Status</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php foreach($musteritipleri as $musteritipi){ ?>
                        <tr>
                          <td><?php echo $musteritipi['customer_type_name']; ?></td>
                          <td><?php echo $musteritipi['created_at']; ?></td>
                          <td><?php echo $musteritipi['user_name']; ?></td>
                          <?php if($musteritipi['customer_type_is_delete']==0){ ?>
                            <td>Aktif</td>
                          <?php  } else{ ?>
                            <td>Pasif</td>
                          <?php } ?>
                          <?php if($_SESSION['type']=="Admin"){ ?>
                            <td>
                              <a class="btn btn-sm btn-primary" data-bs-toggle="modal" tip-id="<?php echo $musteritipi['customer_type_id']; ?>" tip-name="<?php echo $musteritipi['customer_type_name']; ?>" tip-status="<?php echo $musteritipi['customer_type_is_delete']; ?>" onclick="gettipdatas(this)" style="color:white;" data-bs-target="#smallModaledit">Düzenle<i class="bi bi-pen"></i></a>
                              
                              <a class="btn btn-sm btn-danger" data-bs-toggle="modal" style="color:white;" id="deletebuton" tip-id="<?php echo $musteritipi['customer_type_id']; ?>" onclick="getdata('<?php echo $musteritipi['customer_type_id']; ?>')" data-bs-target="#smallModaldelete">Sil<i class="bi bi-trash"></i></a>

                              
                            </td>

                         <?php } ?>
                        </tr> 
                     <?php } ?>                         
                        

                        <div class="modal fade" tabindex="-1" id="smallModaldelete" role="dialog" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <form action="?pg=delete" method="POST">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title">Uyarı</h5>
                                      <button type="button" class="close" data-dismiss="modal" onclick="closingmodal()"  aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <p>Silmek istediğinize emin misiniz?</p>
                                    </div>
                                    <input type="hidden"  name="delete_id" id="delete_id">
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" id="closing" data-dismiss="modal" onclick="closingmodal()">Vazgeç</button>
                                      <button type="submit" class="btn btn-primary">Sil</button>
                                    </div>
                                    </form>
                                  </div>
                                </div>
                              </div>


                      
                    </tbody>
                  </table>

              
                </div>
              </div>

              <div class="modal fade" id="smallModal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-sm" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Müşteri Tipi Ekle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <form action="?pg=insert" method="POST">
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Tipi Adı</label>
                                  <input type="text" id="customer_type_name" name="customer_type_name" class="form-control" placeholder="Enter Name" required/>
                                </div>
                              </div>                              
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Status</label>
                                  <select class="form-select" name="customer_type_is_delete" id="customer_type_is_delete" required>
                                    <option value="0">Aktif</option>
                                    <option value="1">Pasif</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>


                      <div class="modal fade" id="smallModaledit" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Müşteri Tipi Güncelle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <form action="?pg=update" method="POST">
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Tipi Adı</label>
                                  <input type="text" id="customertype_editname" name="customertype_name" class="form-control" placeholder="Enter Name" required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Status</label>
                                  <select class="form-select" name="customertypeis_delete" id="customertypeeditisdelete" required>
                                    
                                  </select>
                                </div>
                              </div>                                  
                            </div>
                            <input type="hidden" id="customertype_editid" name="customertype_id">
                            <div class="modal-footer">
                              <button type="button" id="closeupdate" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closingupdate()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>



          
              <!-- Layout Demo -->
              
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>

          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <!-- / Layout wrapper -->



    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    
  </body>

  <?php
    if(isset($_GET['pg'])){
      $pg=$_GET['pg'];
      if($pg=='insert'){
        $musteritipi=$_POST['customer_type_name'];
        $status=$_POST['customer_type_is_delete'];
        $db=new crud();
        $sonuc=$db->insertcustomertype($musteritipi,$status);
        if($sonuc['status']){
          $_SESSION['success_message']="Müşteri tipi başarıyla kaydedildi.";
          $log_summary = [
                    'post' => $_POST,
                ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> 0,
              'type'     => 'A',
              'method'   => 'POST',
              'title'    => 'Müşteri tipi Ekleme',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          header('Location: musteritipleri.php');
        }
        else{
          $_SESSION['error_message']="Kayıt başarısız";
          header('Location: musteritipleri.php');
        }
      }
      else if($pg=='update'){
        $musteritipi=$_POST['customertype_name'];
        $status=$_POST['customertypeis_delete'];
        $id=$_POST['customertype_id'];
        $db=new crud();
        $sonuc=$db->updatecustomertype($musteritipi,$status,$id);
        if($sonuc['status']){
          $_SESSION['success_message']="Müşteri tipi başarıyla güncellendi.";
          $log_summary = [
                    'post' => $_POST,
                ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> 0,
              'type'     => 'U',
              'method'   => 'PUT',
              'title'    => 'Müşteri tipi Güncelleme',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          header('Location: musteritipleri.php');
        }
        else{
          $_SESSION['error_message']="Güncelleme başarısız";
          header('Location: musteritipleri.php');
        }
      }
      else if($pg='delete'){
        $delete_id=$_POST['delete_id'];
        $db=new crud();
        $sonuc=$db->updatestatus("customer_types","customer_type_id","customer_type_is_delete",$id);
        if($sonuc['status']){
          $_SESSION['success_message']="Müşteri tipi başarıyla silindi.";
          $log_summary = [
                    'post' => $_POST,
                ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> 0,
              'type'     => 'D',
              'method'   => 'DELETE',
              'title'    => 'Müşteri tipi silme',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          header('Location: musteritipleri.php');
        }
        else{
          $_SESSION['error_message']="Silme başarısız";
          header('Location: musteritipleri.php');
        }
      }
    }



  ?>

</html>
<script src="assets/js/main.js"></script>
<script src="assets/js/ui-toasts.js"></script>

<script>
  function closingmodal(){
    $('#smallModaldelete').modal('toggle');
  }
</script>

<script>
  function getdata(attr){
    $('#smallModaldelete').modal('show');
    $('#delete_id').val(attr);
  }
  function gettipdatas(attr){
    var tipstatus=$(attr).attr('tip-status');
    console.log(tipstatus);
    var tipid=$(attr).attr('tip-id');
    var tipname=$(attr).attr('tip-name');
    $('#customertype_editname').val(tipname);
    $('#customertype_editid').val(tipid);
    $.ajax({
      method:'post',
      url: 'ajax.php',
      data:{tipstatus:tipstatus},
      dataType: 'html',
      success: function(datam){
        $('#customertypeeditisdelete').html(datam);
      }
    });
  }
</script>

<script>
  $(".multiple-select").select2({
    maximumSelectionLength: 2
  });



</script>