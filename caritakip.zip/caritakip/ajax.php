<?php
require_once 'class.crud.php';
if(isset($_POST['customer_type_id']) && !empty($_POST['customer_type_id'])){
    $dbase=new crud();
    $services=$dbase->wread("services","customer_type_id",$_POST['customer_type_id']);
    $html = '<option value="0">Modül Seçin</option>';
    foreach($services as $service){
        $html .= '<option value="'.$service['service_id'].'" >'.$service['service_name'].'</option>';
    }
    echo $html;
}

if(isset($_POST['customer_type']) && !empty($_POST['customer_type'])){
    $dbase=new crud();
    $customers=$dbase->wread("customers","customer_type_id",$_POST['customer_type']);
    $html = '<option value="0">Müşteri Seçin</option>';
    foreach($customers as $customer){
        $html .= '<option value="'.$customer['customer_id'].'" >'.$customer['customer_name'].'</option>';
    }
    echo $html;
}

if(isset($_POST['customer_typenumber']) && !empty($_POST['customer_typenumber'])){
    $dbase=new crud();
    $customer_id=$_POST['customer_id'];
    $customer_type_id=$_POST['customer_typenumber'];
    $customers=$dbase->wread("customers","customer_type_id",$_POST['customer_typenumber']);
    $customertypes=$dbase->read("customer_types");
    $html = '<option value="0">Müşteri Seçin</option>';
    foreach($customers as $customer){
        if($customer['customer_id']==$customer_id){
            $html .= '<option value="'.$customer['customer_id'].'" selected >'.$customer['customer_name'].'</option>';
        }
        else{
            $html .= '<option value="'.$customer['customer_id'].'">'.$customer['customer_name'].'</option>';
        }       
    }
    $htmll = '<option value="0">Müşteri tipi Seçin</option>';
    foreach($customertypes as $customertype){
        if($customertype['customer_type_id']==$customer_type_id){
            $htmll .= '<option value="'.$customertype['customer_type_id'].'" selected >'.$customertype['customer_type_name'].'</option>';
        }
        else{
            $htmll .= '<option value="'.$customertype['customer_type_id'].'">'.$customertype['customer_type_name'].'</option>';
        }    
    }
    echo $html."*".$htmll;
}

if(isset($_POST['customer_edittype']) && !empty($_POST['customer_edittype'])){
    $dbase=new crud();
    $customer_typeid=$_POST['customer_edittype'];
    $customer_name=$_POST['customer_editname'];
    $service_id=$_POST['customer_serviceid'];
    $status=$_POST['customer_isdelete'];
    $services=$dbase->wread("customer_services","customer_type_id",$customer_typeid);
    $customertypes=$dbase->read("customer_types");
    $htmlm = '<option value="0">Müşteri tipi Seçin</option>';
    $htmls = '<option value="0">Modül Seçin</option>';
    $htmli='';
    foreach($services as $service){
        if($service['customer_service_id']==$service_id){
            $htmls .= '<option value="'.$service['customer_service_id'].'" selected >'.$service['service_name'].'</option>';
        }
        else{
            $htmls .= '<option value="'.$service['customer_service_id'].'">'.$service['service_name'].'</option>';
        }       
    }
    foreach($customertypes as $customertype){
        if($customertype['customer_type_id']==$customer_typeid){
            $htmlm .= '<option value="'.$customertype['customer_type_id'].'" selected >'.$customertype['customer_type_name'].'</option>';
        }
        else{
            $htmlm .= '<option value="'.$customertype['customer_type_id'].'">'.$customertype['customer_type_name'].'</option>';
        }    
    }
    if($status==0){
        $htmli .='<option value="0" selected>Aktif</option><option value="1">Pasif</option>';
    }
    else{
        $htmli .='<option value="0">Aktif</option><option value="1" selected>Pasif</option>';
    }
    echo $customer_name."*".$htmlm."*".$htmls."*".$htmli;
}

if(isset($_POST['customer_typeforservice']) && !empty($_POST['customer_typeforservice'])){
    $dbase=new crud();
    $services=$dbase->wread("customer_services","customer_type_id",$_POST['customer_typeforservice']);
    $html = '';
    foreach($services as $service){
        $html .= '<option value="'.$service['customer_service_id'].'" >'.$service['service_name'].'</option>';
    }
    echo $html;
}
if(isset($_POST['customertypeforedit']) && !empty($_POST['customertypeforedit'])){
    $dbase=new crud();
    $services=$dbase->wread("customer_services","customer_type_id",$_POST['customertypeforedit']);
    $html = '';
    foreach($services as $service){
        $html .= '<option value="'.$service['customer_service_id'].'" >'.$service['service_name'].'</option>';
    }
    echo $html;
}

if(isset($_POST['tipstatus'])){
    $status=$_POST['tipstatus'];    
    if($status==0){
        $htmli .='<option value="0" selected>Aktif</option><option value="1">Pasif</option>';
    }
    else{
        $htmli .='<option value="0">Aktif</option><option value="1" selected>Pasif</option>';
    }
    echo $htmli;   
}

if(isset($_POST['musteriinsertid'])){
    $db=new crud();
    $musteri=$db->wread("customers","customer_id",$_POST['musteriinsertid']);
    foreach($musteri as $item){
        $customer_id=$item['customer_id'];
        $customer_type_id=$item['customer_type_id'];
    }
    $alinanservisler=$db->wread("customer_services","customer_id",$customer_id);
    $servisler=$db->wread("services","customer_type_id",$customer_type_id);
    $alinanid=[];
    foreach($alinanservisler as $alinan){
        array_push($alinanid,$alinan['service_id']);
    }
    $alinacakid=[];
    $alinacakname=[];
    foreach($servisler as $service){
        if(!in_array($service['service_id'],$alinanid)){
            array_push($alinacakid,$service['service_id']);
            array_push($alinacakname,$service['service_name']);
        }
    }
    $htmls='<select class="row d-flex justify-content-center mt-100 selectpickers" id="coklusecim" onchange="getbilgi(this)" name="service_name[]" multiple="">';
    for($i=0;$i<count($alinacakid);$i++){
        $htmls .= '<option value="'.$alinacakid[$i].'" >'.$alinacakname[$i].'</option>';
    }   
    $htmls.='</select><script type="text/javascript">
$(document).ready(function() {
    $(".selectpickers").selectpicker();
})  
</script><hr>';
    echo $htmls;
}

if(isset($_POST['serviceforedit'])){
    $db=new crud();
    if($_POST['servis']!=0){
        $veri=['id' => $_POST['service_id']];
        $services=$db->sorgukosullu("SELECT * FROM customer_services cs INNER JOIN services s ON cs.service_id=s.service_id WHERE customer_service_id=?",$veri);
    }else{
        $services=$db->customerservicebycustomerid($_POST['serviceforedit']);
    }
    $html='';
    $inputsayisi=1;
    foreach($services as $service){       
        if($service['customer_service_is_delete']==0){
            $html .='<div class="row">
                                <div class="col mb-3">
                                  
                                  <table class="table">
                                    <tr>                                      
                                      <td>
                                        <label for="nameSmall" class="form-label">Modül Adı</label>
                                        <input type="text" value="'.$service['service_name'].'" name="service_name_'.$inputsayisi.'" class="form-control" placeholder="" readonly/></td>                                      
                                      <td>
                                        <label for="nameSmall" class="form-label">Adeti</label>
                                        <input type="text" value="'.$service['quantity'].'" name="adet_'.$inputsayisi.'" class="form-control" placeholder="" /></td>                                     
                                      <td>
                                        <label for="nameSmall" class="form-label">Status</label>
                                        <select name="status_'.$inputsayisi.'" class="form-control">
                                        <option selected value="0">Aktif</option>
                                        <option value="1">Pasif</option>
                                      </select></td>
                                      <td><input type="hidden" value="'.$service['service_id'].'" name="service_id_'.$inputsayisi.'"></td>
                                      <td>
                                      <label for="nameSmall" class="form-label">Modül Ücreti TL</label>
                                      <input type="text" value="'.$service['service_total_tr'].'" class="form-control" name="total_tr_'.$inputsayisi.'"></td>
                                      <td>
                                      <label for="nameSmall" class="form-label">Modül Ücreti USD</label>
                                      <input type="text" value="'.$service['service_total_usd'].'" class="form-control" name="total_usd_'.$inputsayisi.'"></td>
                                    </tr>
                                  </table>
                                </div>
                            </div>';
        }
        else{
            $html .='<div class="row">
                                <div class="col mb-3">
                                  
                                  <table class="table">
                                    <tr>                                      
                                      <td>
                                        <label for="nameSmall" class="form-label">Modül Adı</label>
                                        <input type="text"  name="service_name_'.$inputsayisi.'" class="form-control" placeholder="" value="'.$service['service_name'].'" readonly/></td>                                      
                                      <td>
                                        <label for="nameSmall" class="form-label">Adeti</label>
                                        <input type="text"  value="'.$service['quantity'].'" name="adet_'.$inputsayisi.'"" class="form-control" placeholder="" /></td>                                     
                                      <td>
                                        <label for="nameSmall" class="form-label">Status</label>
                                        <select name="status_'.$inputsayisi.'" class="form-control">
                                        <option value="0">Aktif</option>
                                        <option selected value="1">Pasif</option>
                                      </select></td>
                                      <td><input type="hidden" value="'.$service['service_id'].'" name="service_id_'.$inputsayisi.'"></td>
                                      <td>
                                      <label for="nameSmall" class="form-label">Modül Ücreti TL</label>
                                      <input type="text" value="'.$service['service_total_tr'].'" class="form-control" name="total_tr_'.$inputsayisi.'"></td>
                                      <td>
                                      <label for="nameSmall" class="form-label">Modül Ücreti USD</label>
                                      <input type="text" value="'.$service['service_total_usd'].'" class="form-control" name="total_usd_'.$inputsayisi.'"></td>
                                    </tr>
                                  </table>                                
                                </div>
                            </div>';
        }
        $inputsayisi+=1;
    }
    echo $html."*".$inputsayisi;
}
        


if(isset($_POST['statusserviceedit'])){
    $status=$_POST['statusserviceedit'];
    $service_id=$_POST['service_id'];
    $htmli='';
    $htmlm='';
    $db=new crud();
    $service=$db->wread("services","service_id",$service_id);
    $musteritipleri=$db->read("customer_types");
    foreach($service as $item){
        $service_name=$item['service_name'];
        $customer_type_id=$item['customer_type_id'];
    }
    if($status==0){
        $htmli .='<option value="0" selected>Aktif</option><option value="1">Pasif</option>';
    }
    else{
        $htmli .='<option value="0">Aktif</option><option value="1" selected>Pasif</option>';
    }
    foreach($musteritipleri as $musteritipi){
        if($musteritipi['customer_type_id']==$customer_type_id){
            $htmlm .= '<option value="'.$musteritipi['customer_type_id'].'" selected >'.$musteritipi['customer_type_name'].'</option>';
        }
        else{
            $htmlm .= '<option value="'.$musteritipi['customer_type_id'].'">'.$musteritipi['customer_type_name'].'</option>';
        }    
    }
    echo $service_name."*".$htmlm."*".$htmli;
}

if(isset($_POST['inputname'])){
    $musteri=$_POST['inputname'];
    $servis=$_POST['inputservis'];
    $paginate=5;
    if(isset($_POST["page"])){
        $sayfa=$_POST['page'];
    }else{
         $sayfa=1;
    }
   
    $sayfa1=($sayfa*$paginate)-$paginate;
    $db=new crud();
    if((empty($musteri) OR $musteri=='') && $servis==0){
        $veri=['is_delete' => 0];
        $customerservices=$db->sorgukosullu("SELECT * ,GROUP_CONCAT(v.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(s.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(s.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(s.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(s.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services s INNER JOIN customer_types t ON s.customer_type_id=t.customer_type_id INNER JOIN customers c ON s.customer_id=c.customer_id INNER JOIN users u ON s.user_id=u.user_id INNER JOIN services v ON s.service_id=v.service_id WHERE s.customer_service_is_delete=? GROUP BY c.customer_id ORDER BY s.customer_id ASC LIMIT $sayfa1, $paginate",$veri);
        $cservisler=$db->sorgukosullucount("SELECT * ,GROUP_CONCAT(v.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(s.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(s.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(s.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(s.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services s INNER JOIN customer_types t ON s.customer_type_id=t.customer_type_id INNER JOIN customers c ON s.customer_id=c.customer_id INNER JOIN users u ON s.user_id=u.user_id INNER JOIN services v ON s.service_id=v.service_id WHERE s.customer_service_is_delete=? GROUP BY c.customer_id ORDER BY s.customer_id",$veri);
        $sayfasayisi=ceil($cservisler/$paginate);
    }
    else if(empty($musteri)){
        $veri=['id' => $servis, 'is_delete' => 0];
        $customerservices=$db->sorgukosullu("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(h.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE h.service_id=? AND h.customer_service_is_delete=? GROUP BY h.customer_service_id ORDER BY h.customer_service_id ASC LIMIT $sayfa1, $paginate",$veri);
        $cservisler=$db->sorgukosullucount("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(h.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE h.service_id=? AND h.customer_service_is_delete=? GROUP BY h.customer_service_id",$veri);
        $sayfasayisi=ceil($cservisler/$paginate);
    }
    else if($servis==0){
        $veri=['musteri' => "%$musteri%", 'is_delete' => 0];
        $customerservices=$db->sorgukosullu("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(h.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE c.customer_name LIKE ? AND h.customer_service_is_delete=? GROUP BY c.customer_id LIMIT $sayfa1, $paginate",$veri);
        $cservisler=$db->sorgukosullucount("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(h.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE c.customer_name LIKE ? AND h.customer_service_is_delete=? GROUP BY c.customer_id",$veri);
        $sayfasayisi=ceil($cservisler/$paginate);
    }
    else if(!empty($musteri) && $servis!=0){
        $veri=['musteri' => "%$musteri%", 'id' => $servis, 'cis' => 0];
        $customerservices=$db->sorgukosullu("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(h.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE c.customer_name LIKE ? AND h.service_id=? AND h.customer_service_is_delete=? GROUP BY c.customer_id, s.service_id ORDER BY c.customer_id ASC LIMIT $sayfa1, $paginate",$veri);
        $cservisler=$db->sorgukosullucount("SELECT *, GROUP_CONCAT(s.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(h.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(h.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(h.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(h.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services h INNER JOIN customers c ON h.customer_id=c.customer_id INNER JOIN services s ON h.service_id=s.service_id INNER JOIN users u ON h.user_id=u.user_id WHERE c.customer_name LIKE ? AND h.service_id=? AND h.customer_service_is_delete=? GROUP BY c.customer_id, s.service_id",$veri);
        $sayfasayisi=ceil($cservisler/$paginate);
    }
    
    $htmlt='';
    $htmlp='';
    foreach($customerservices as $service){
        if($service['customer_service_is_delete']==0){
            if($_SESSION['type']=="Admin"){
                $htmlt .='<tr>
                          <td>'.$service['customer_name'].'</td>
                          <td>'.$service['servisname'].'</td>
                          <td>'.$service['miktar'].'</td>
                          <td>'.$service['servisucrettr'].'</td>
                          <td>'.$service['servisucretusd'].'</td>
                          <td>
                              <a class="btn btn-sm btn-primary" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaleditservice" id="buton" customer-type-id="'.$service['customer_type_id'].'" customer-id="'.$service['customer_id'].'" service-name="'.$service['service_name'].'" service-id="'.$service['customer_service_id'].'" onclick="getdataforedit(this)" >Düzenle<i class="bi bi-pen"></i></a>                                                         

                              <a class="btn btn-sm btn-danger" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaldeleteservice" id="silmebutonu" customer-id="'.$service['customer_id'].'" delete-id="'.$service['customer_service_id'].'" onclick="getdata(this)">Sil<i class="bi bi-trash"></i></a>
                            </td>
                          </tr>';
            }
            else{
                $htmlt .='<tr>
                          <td>'.$service['customer_name'].'</td>
                          <td>'.$service['servisname'].'</td>
                          <td>'.$service['miktar'].'</td>
                          <td>'.$service['servisucrettr'].'</td>
                          <td>'.$service['servisucretusd'].'</td>
                          <tr>';
            }
            
        }
        else{
            if($_SESSION['type']=="Admin"){
                $htmlt .='<tr>
                          <td>'.$service['customer_name'].'</td>
                          <td>'.$service['servisname'].'</td>
                          <td>'.$service['miktar'].'</td>
                          <td>'.$service['servisucrettr'].'</td>
                          <td>'.$service['servisucretusd'].'</td>
                          <td>
                              <a class="btn btn-sm btn-primary" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaleditservice" id="buton" customer-type-id="'.$service['customer_type_id'].'" customer-id="'.$service['customer_id'].'" service-name="'.$service['service_name'].'" service-id="'.$service['customer_service_id'].'" onclick="getdataforedit(this)" >Düzenle<i class="bi bi-pen"></i></a>                                                         

                              <a class="btn btn-sm btn-danger" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaldeleteservice" id="silmebutonu" customer-id="'.$service['customer_id'].'" delete-id="'.$service['customer_service_id'].'" onclick="getdata(this)">Sil<i class="bi bi-trash"></i></a>
                            </td>
                          </tr>';
            }
            else{
                $htmlt .='<tr>
                          <td>'.$service['customer_name'].'</td>
                          <td>'.$service['servisname'].'</td>
                          <td>'.$service['miktar'].'</td>
                          <td>'.$service['servisucrettr'].'</td>
                          <td>'.$service['servisucretusd'].'</td>
                          <tr>';
            }
        }        
    }
    if($sayfasayisi > 1):
      if(isset($_POST["page"])):
          if(is_numeric($_POST["page"])):
                $sayfa = $_POST["page"];
          else:
                $sayfa = 1;
          endif;
      else:
        $sayfa = 1;
      endif;

    $htmlp .='<div class="b-pagination-outer mt-5"><ul id="border-pagination">';
    if(isset($_POST["page"]) && $_POST["page"] > 1){
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa-1).'">«</a></li>';
        if($_POST["page"] > 3){
            $htmlp .='<li><a onclick="pagination(this)" page-id="1">1</a></li>';
            if($sayfa>4){
                $htmlp .='<li><a href="javascript:;" >...</a></li>';
            }
        }
    }
    for($i=$sayfa-2; $i<=$sayfa+2; $i++){
        if($i> 0 && $i<=$sayfasayisi){
            if($i == $sayfa){
                $htmlp .='<li><a href="javascript:;" class="active">'.$i.'</a></li>';
            }else{
                $htmlp .='<li><a onclick="pagination(this)" page-id="'.$i.'">'.$i.'</a></li>';
            }
        }
    }
    if($sayfa < $sayfasayisi-2){
        if($sayfa+3<$sayfasayisi){
            $htmlp .='<li><a href="javascript:;" >...</a></li>';
        }
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.$sayfasayisi.'">'.$sayfasayisi.'</a></li>';
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa+1).'">»</a></li>';
    }
    else{
        if($sayfa != $sayfasayisi){
            $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa+1).'">»</a></li>';
        }
    }
    $htmlp .='</ul></div>
                ';
            endif;
            $htmlp .='</div>';
    echo $htmlt."*".$htmlp;
}










if(isset($_POST['servissayisi'])){
    $sayac=$_POST['servissayisi'];
    $htmla='';
    if($sayac!=0){
        $servisler=$_POST['alinanservisler'];
        $db=new crud();
        $sisimler=[];
        foreach($servisler as $servis){
            $serv=$db->wread("services","service_id",$servis);
            foreach($serv as $item){
                array_push($sisimler,$item['service_name']);
            }
        }
        $index=1;
        $sindex=0;
        foreach($servisler as $servis){
            $htmla .='<div class="row">
                        <div class="col mb-3">
                                <input type="text"  name="adet_'.$index.'" class="form-control btn-sm" placeholder="'.$sisimler[$sindex].' Adet girin" required/>                                                                
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-3">
                                <input type="text"  name="total_tr_'.$index.'" class="form-control btn-sm" placeholder="'.$sisimler[$sindex].' TL ücretini girin" required/>                                                                
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-3">
                                <input type="text"  name="total_usd_'.$index.'" class="form-control btn-sm" placeholder="'.$sisimler[$sindex].' USD ücretini girin" required/>                                                                
                        </div>
                    </div>';
            $index+=1;
            $sindex+=1;
        }
    }
    echo $htmla."*".$sayac;
}

if(isset($_POST['customerfordelete'])){
    $customer_id=$_POST['customerfordelete'];
    $db=new crud();
    $cservices=$db->findcustomerservicesbycustomerid($customer_id);
    $htmls='<select class="row d-flex justify-content-center mt-100 selectmulti"  name="service_id[]" multiple="">';
    foreach($cservices as $cservice){
        $htmls .= '<option value="'.$cservice['service_id'].'" >'.$cservice['service_name'].'</option>';
    }   
    $htmls.='</select><script type="text/javascript">
    $(document).ready(function() {
    $(".selectmulti").selectpicker();
    })  
    </script>';
    echo $htmls;
}

if(isset($_POST['cserviceedit'])){
    $cservice_id=$_POST['cserviceedit'];
    $db=new crud();
    $cservice=$db->customerservicebyid($cservice_id);
    $htmlu='';
    foreach($cservice as $item){
        $htmlu .='<div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Adı</label>
                                  <input type="text" id="customer_editname" name="customer_name" class="form-control" value="'.$item['customer_name'].'" readonly/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Aldığı Modül</label>
                                  <input type="text" id="service" name="customer_name" class="form-control" value="'.$item['service_name'].'" readonly/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Adet</label>
                                  <input type="text" id="quantity" name="quantity" class="form-control" value="'.$item['quantity'].'" required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                              <select name="is_delete" class="form-control">';
        if($item['customer_service_is_delete']==0){
            $htmlu .='<option selected value="0">Aktif</option>
                                        <option value="1">Pasif</option></select></div></div>';
        }else{
            $htmlu .='<option value="0">Aktif</option>
                                        <option selected value="1">Pasif</option></select></div></div>';
        }                                   
    }
    echo $htmlu;
}

if(isset($_POST['usereditid'])){
    $db=new crud();
    $veri=['id' =>$_POST['usereditid']];
    $user=$db->sorgukosullu("SELECT * FROM users WHERE user_id=?",$veri);
    foreach($user as $item){
        $name=$item['user_name'];
        $email=$item['email'];
        $type=$item['type'];
        $phone=$item['phone_number'];
    }
    $htmlp='';
    $tkod=[];
    $tarray=[];
    for($i=0;$i<strlen($phone);$i++){
      if($i>=0 && $i<2){
        array_push($tkod,$phone[$i]);
      }
      else{
        array_push($tarray,$phone[$i]);
      }
    }
    $tarray=implode("",$tarray);
    $tkod=implode("",$tkod);
    if($tkod=="90"){
        $htmlp .='<select class="form-select btn-sm" name="kod" required>                                                                         
                                      <option value="90" selected>TR +90</option>
                                      <option value="1">US +1</option>                                              
                                    </select>';
    }else{
        $htmlp .='<select class="form-select btn-sm" name="kod" required>                                                                         
                                      <option value="90">TR +90</option>
                                      <option value="1" selected>US +1</option>                                              
                                    </select>';
    }
    $htmlt='';
    if($type=="Admin"){
        $htmlt .='<select class="form-select btn-sm" name="type" required>                                                                         
                                      <option value="Admin" selected>Admin</option>
                                      <option value="User">User</option>                                              
                                    </select> ';
    }else{
        $htmlt .='<select class="form-select btn-sm" name="type" required>                                                                         
                                      <option value="Admin">Admin</option>
                                      <option value="User" selected>User</option>                                              
                                    </select> ';
    }
    echo $name."*".$email."*".$htmlp."*".$tarray."*".$htmlt;
}

if(isset($_POST['c_is_delete'])){
    $c_is_delete=$_POST['c_is_delete'];
    $sayfa=$_POST['page'];
    $paginate=5;
    if(isset($_POST["page"])){
        $sayfa=$_POST['page'];
    }else{
         $sayfa=1;
    }   
    $sayfa1=($sayfa*$paginate)-$paginate;
    $db=new crud();
    if($c_is_delete==-1){
        $customers=$db->sorgu("SELECT * FROM customers c INNER JOIN customer_types t ON c.customer_type_id=t.customer_type_id  INNER JOIN users u ON c.user_id=u.user_id ORDER BY customer_id ASC LIMIT $sayfa1, $paginate");
        $ccustomers=$db->sorgucount("SELECT * FROM customers c INNER JOIN customer_types t ON c.customer_type_id=t.customer_type_id  INNER JOIN users u ON c.user_id=u.user_id");
    }else{
        $veri=['customer_is_delete' => $c_is_delete];
        $ccustomers=$db->sorgukosullucount("SELECT * FROM customers WHERE customer_is_delete=?",$veri);
        $customers=$db->sorgukosullu("SELECT * FROM customers c INNER JOIN customer_types t ON c.customer_type_id=t.customer_type_id  INNER JOIN users u ON c.user_id=u.user_id WHERE customer_is_delete=? ORDER BY customer_id ASC LIMIT $sayfa1, $paginate",$veri);
    } 
    $sayfasayisi=ceil($ccustomers/$paginate);
    $htmlt='';
    $htmlp='';
    foreach($customers as $customer){
        if($_SESSION['type']=="Admin"){
            $htmlt .='<tr><td>'.$customer['customer_name'].'</td>
                          <td>'.$customer['customer_type_name'].'</td>
                          <td>'.$customer['casual_date'].'</td>
                          <td>'.$customer['customer_add_date'].'</td>
                          <td>'.$customer['customer_edit_date'].'</td>
                          <td class="text-center" >'.$customer['pay_total_tr'].'</td>
                          <td class="text-center" >'.$customer['pay_total_usd'].'</td>
                          <td class="text-center">
                              <a class="btn btn-sm btn-primary" data-bs-toggle="modal" style="color:white;" data-bs-target="#Modaleditcustomer" service-id="'.$customer['customer_service_id'].'" customer-type="'.$customer['customer_type_id'].'" customer-status="'.$customer['customer_is_delete'].'" customer-name="'.$customer['customer_name'].'" customer-id="'.$customer['customer_id'].'" onclick="get_customer(this)" id="editbuton">Düzenle<i class="bi bi-pen"></i></a>                                                         

                              <a class="btn btn-sm btn-danger" data-bs-toggle="modal" style="color:white;" data-bs-target="#Modaldeletecustomer" id="silmebutonu" customer-id="'.$customer['customer_id'].'"  onclick="getdata(this)">Sil<i class="bi bi-trash"></i></a>
                            </td></tr>';
        }else{
            $htmlt .='<tr><td>'.$customer['customer_name'].'</td>
                          <td>'.$customer['customer_type_name'].'</td>
                          <td>'.$customer['casual_date'].'</td>
                          <td>'.$customer['customer_add_date'].'</td>
                          <td>'.$customer['customer_edit_date'].'</td>
                          <td class="text-center" >'.$customer['pay_total_tr'].'</td>
                          <td class="text-center" >'.$customer['pay_total_usd'].'</td></tr>';
        }
    }
    if($sayfasayisi > 1):
      if(isset($_POST["page"])):
          if(is_numeric($_POST["page"])):
                $sayfa = $_POST["page"];
          else:
                $sayfa = 1;
          endif;
      else:
        $sayfa = 1;
      endif;

    $htmlp .='<div class="b-pagination-outer mt-5"><ul id="border-pagination">';
    if(isset($_POST["page"]) && $_POST["page"] > 1){
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa-1).'">«</a></li>';
        if($_POST["page"] > 3){
            $htmlp .='<li><a onclick="pagination(this)" page-id="1">1</a></li>';
            if($sayfa>4){
                $htmlp .='<li><a href="javascript:;" >...</a></li>';
            }
        }
    }
    for($i=$sayfa-2; $i<=$sayfa+2; $i++){
        if($i> 0 && $i<=$sayfasayisi){
            if($i == $sayfa){
                $htmlp .='<li><a href="javascript:;" class="active">'.$i.'</a></li>';
            }else{
                $htmlp .='<li><a onclick="pagination(this)" page-id="'.$i.'">'.$i.'</a></li>';
            }
        }
    }
    if($sayfa < $sayfasayisi-2){
        if($sayfa+3<$sayfasayisi){
            $htmlp .='<li><a href="javascript:;" >...</a></li>';
        }
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.$sayfasayisi.'">'.$sayfasayisi.'</a></li>';
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa+1).'">»</a></li>';
    }
    else{
        if($sayfa != $sayfasayisi){
            $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa+1).'">»</a></li>';
        }
    }
    $htmlp .='</ul></div>
                ';
            endif;
            $htmlp .='</div>';
    echo $htmlt."*".$htmlp;
}
if(isset($_POST['log_id'])){
    $log_id=$_POST['log_id'];
    $db=new crud();
    $veri=['id' => $log_id];
    $log=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id INNER JOIN action_logs_ips i ON a.ip_id=i.id WHERE a.log_id=?",$veri);

    $htmll='';
    foreach($log as $item){
        $bilgi=json_decode($item['summary'],true);
        $htmll .='<div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Yapılan İşlem</label>
                    <input type="text" name="title_name" class="form-control" value="'.$item['title_name'].'" readonly/>
                        </div>
                </div>';
        if($item['title_id']==8 OR $item['title_id']==9 OR $item['title_id']==15){
            $htmll .='<div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Müşteri Adı</label>
                    <input type="text"  name="title_servis" class="form-control" value="'.$bilgi['post']['customer_name'].'" readonly/>
                        </div>
                </div>';
            for($i=1;$i<=$bilgi['post']['inputsayisi'];$i++){
                $htmll .='
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Modül Adı</label>
                    <input type="text" name="title_servis" class="form-control" value="'.$bilgi['post']['service_name_'.$i.''].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Modül Adeti</label>
                    <input type="text" name="adet_servis" class="form-control" value="'.$bilgi['post']['adet_'.$i.''].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Modül Ücret TL</label>
                    <input type="text" name="total_tr_servis" class="form-control" value="'.$bilgi['post']['total_tr_'.$i.''].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Modül Ücret USD</label>
                    <input type="text" name="total_tr_servis" class="form-control" value="'.$bilgi['post']['total_usd_'.$i.''].'" readonly/>
                        </div>
                </div><hr>';
            }
        }
        else if($item['title_id']==7 OR $item['title_id']==10 OR $item['title_id']==14){
            $htmll .='<div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Müşteri Adı</label>
                    <input type="text" name="title_servis" class="form-control" value="'.$bilgi['post']['customer_name'].'" readonly/>
                        </div>
                </div>';
            if($item['title_id']==10){
                $htmll .='<div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Silinme Tarihi</label>
                    <input type="text"  name="title_servis" class="form-control" value="'.$bilgi['post']['silinme_tarihi'].'" readonly/>
                        </div>
                </div>';
            }else if($item['title_id']==7){
                $htmll .='<div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Sözleşme Tarihi</label>
                    <input type="text" name="casual_date" class="form-control" value="'.$bilgi['post']['casual'].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Ödeme Tutarı TL</label>
                    <input type="text" name="pay_total_tr" class="form-control" value="'.$bilgi['post']['pay_total_tr'].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Ödeme Tutarı USD</label>
                    <input type="text" name="pay_total_usd" class="form-control" value="'.$bilgi['post']['pay_total_usd'].'" readonly/>
                        </div>
                </div>';
            }else if($item['title_id']==14){
                $htmll .='<div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Müşteri Tipi</label>
                    <input type="text" name="customer_type_name" class="form-control" value="'.$bilgi['post']['customer_type_name'].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Güncellenme Tarihi</label>
                    <input type="text" name="customer_edit_date" class="form-control" value="'.$bilgi['post']['customer_edit_date'].'" readonly/>
                        </div>
                </div>';
            }
        }else if($item['title_id']==4 OR $item['title_id']==5){
                $htmll .='<div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Girilen Email</label>
                    <input type="text"  name="email" class="form-control" value="'.$bilgi['post']['email'].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Girilen Şifre</label>
                    <input type="text"  name="pass" class="form-control" value="'.$bilgi['post']['pass'].'" readonly/>
                        </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                    <label for="nameSmall" class="form-label">Girilmeye Çalışılan IP Adresi</label>
                    <input type="text" name="customer_type_name" class="form-control" value="'.$item['ip'].'" readonly/>
                        </div>
                </div>';
        }else if($item['title_id']==6){
            $htmll .='<div class="row">
            <div class="col mb-3">
            <label for="nameSmall" class="form-label">Giriş Yapan Kullanıcımız</label>
            <input type="text"  name="user_name" class="form-control" value="'.$bilgi['post']['name'].'" readonly/>
            </div>
            </div>
            <div class="row">
            <div class="col mb-3">
                <label for="nameSmall" class="form-label">Giriş Yaptığı Tarih</label>
                 <input type="text"  name="tarih" class="form-control" value="'.$bilgi['post']['girilen_zaman'].'" readonly/>
                        </div>
                </div>';
        }else if($item['title_id']==11 OR $item['title_id']==12 OR $item['title_id']==13){
            if($item['title_id']==13){
                    $htmll .='<div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Kullanıcı Adı</label>
                <input type="text"  name="user_name" class="form-control" value="'.$bilgi['post']['user_name'].'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Kullanıcı Mail</label>
                <input type="text"  name="email" class="form-control" value="'.$bilgi['post']['email'].'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Kullanıcı Telefonu</label>
                <input type="text"  name="phone_number" class="form-control" value="'.$bilgi['post']['phone_number'].'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Yetki</label>
                <input type="text"  name="type" class="form-control" value="'.$bilgi['post']['type'].'" readonly/>
                </div>
                </div>';
            }
            else if($item['title_id']==11){
                $name=$bilgi['post']['firstname']." ".$bilgi['post']['lastname'];
                $htmll .='<div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Kullanıcı Adı</label>
                <input type="text"  name="user_name" class="form-control" value="'.$name.'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Kullanıcı Mail</label>
                <input type="text"  name="email" class="form-control" value="'.$bilgi['post']['email'].'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Kullanıcı Telefonu</label>
                <input type="text"  name="phone_number" class="form-control" value="'.$bilgi['post']['phonenumber'].'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Adresi</label>
                <input type="text"  name="address" class="form-control" value="'.$bilgi['post']['address'].'" readonly/>
                </div>
                </div>';
            }else if($item['title_id']==12){
                $htmll .='<div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Kullanıcı Adı</label>
                <input type="text"  name="user_name" class="form-control" value="'.$bilgi['post']['user_name'].'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Ekleyen Kullanıcı</label>
                <input type="text"  name="user_add_name" class="form-control" value="'.$item['user_name'].'" readonly/>
                </div>
                </div>
                <div class="row">
                <div class="col mb-3">
                <label for="nameSmall" class="form-label">Eklenen Tarih</label>
                <input type="text"  name="add_date" class="form-control" value="'.$item['add_date'].'" readonly/>
                </div>
                </div>';
            }
        }
    } 
    echo $htmll;
}

if($_POST['logpaginate']){
    $paginate=5;
    if(isset($_POST["page"])){
        $sayfa=$_POST['page'];
    }else{
         $sayfa=1;
    }
    $sayfa1=($sayfa*$paginate)-$paginate;
    $db=new crud();
    $start_date=$_POST['start_date'];
    $end_date=$_POST['end_date'];
    $user_name=$_POST['user_name'];
    $log_type=$_POST['log_type'];
    if($start_date=="" AND $end_date=="" AND $log_type==0 AND $user_name==0){
        $logs=$db->sorgu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate");
        $clogs=$db->sorgucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id ORDER BY a.log_id");
    }else if($start_date!="" AND $end_date=="" AND $log_type==0 AND $user_name==0){
        $veri=['start_date' =>$start_date];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? ORDER BY a.log_id",$veri);
    }else if($start_date=="" AND $end_date!="" AND $log_type==0 AND $user_name==0){
        $veri=['end_date' =>$end_date];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? ORDER BY a.log_id",$veri);
    }else if($start_date=="" AND $end_date=="" AND $log_type>0 AND $user_name==0){
        $veri=['log_type' =>$log_type];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.type_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.type_id=? ORDER BY a.log_id",$veri);
    }else if($start_date=="" AND $end_date=="" AND $log_type==0 AND $user_name!=0){
        $veri=['user_name' =>$user_name];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.user_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.user_id=? ORDER BY a.log_id",$veri);
    }else if($start_date!="" AND $end_date!="" AND $log_type==0 AND $user_name==0){
        $veri=['start_date' =>$start_date, 'end_date' =>$end_date];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.add_date<=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.add_date<=? ORDER BY a.log_id",$veri);
    }else if($start_date!="" AND $end_date=="" AND $log_type!=0 AND $user_name==0){
        $veri=['start_date' =>$start_date, 'log_type' =>$log_type];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.type_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.type_id=? ORDER BY a.log_id",$veri);
    }else if($start_date!="" AND $end_date=="" AND $log_type==0 AND $user_name!=0){
        $veri=['start_date' =>$start_date, 'user_name' =>$user_name];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.user_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.user_id=? ORDER BY a.log_id",$veri);
    }else if($start_date=="" AND $end_date!="" AND $log_type!=0 AND $user_name==0){
        $veri=['end_date' =>$end_date, 'log_type' =>$log_type];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.type_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.type_id=? ORDER BY a.log_id",$veri);
    }else if($start_date=="" AND $end_date!="" AND $log_type==0 AND $user_name!=0){
        $veri=['end_date' =>$end_date, 'user_name' =>$user_name];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.user_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.user_id=? ORDER BY a.log_id",$veri);
    }else if($start_date=="" AND $end_date=="" AND $log_type!=0 AND $user_name!=0){
        $veri=['log_type' =>$log_type, 'user_name' =>$user_name];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.type_id=? AND a.user_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.type_id=? AND a.user_id=? ORDER BY a.log_id",$veri);
    }else if($start_date!="" AND $end_date!="" AND $log_type!=0 AND $user_name==0){
        $veri=['start_date' =>$start_date, 'end_date' =>$end_date, 'log_type' => $log_type];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.add_date<=? AND a.type_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.add_date<=? AND a.type_id=? ORDER BY a.log_id",$veri);
    }else if($start_date!="" AND $end_date!="" AND $log_type==0 AND $user_name!=0){
        $veri=['start_date' =>$start_date, 'end_date' =>$end_date, 'user_name' => $user_name];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.add_date<=? AND a.user_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.add_date<=? AND a.user_id=? ORDER BY a.log_id",$veri);
    }else if($start_date!="" AND $end_date=="" AND $log_type!=0 AND $user_name!=0){
        $veri=['start_date' =>$start_date, 'log_type' =>$log_type, 'user_name' => $user_name];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.type_id=? AND a.user_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date>=? AND a.type_id=? AND a.user_id=? ORDER BY a.log_id",$veri);
    }else if($start_date=="" AND $end_date!="" AND $log_type!=0 AND $user_name!=0){
        $veri=['end_date' =>$end_date, 'log_type' =>$log_type, 'user_name' => $user_name];
        $logs=$db->sorgukosullu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.type_id=? AND a.user_id=? ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate",$veri);
        $clogs=$db->sorgukosullucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id WHERE a.add_date<=? AND a.type_id=? AND a.user_id=? ORDER BY a.log_id",$veri);
    }

    $sayfasayisi=ceil($clogs/$paginate);
    $htmll='';
    $htmlt='';
    $htmlp='';
    foreach($logs as $log){
        if($log['response']==17){
            $htmll .='<tr><td>'.$log['title_name'].'</td>
                          <td>'.$log['user_name'].'</td>
                          <td>'.$log['type_name'].'</td>
                          <td>'.$log['add_date'].'</td>
                          <td>Başarılı</td>
                          <td class="text-center">
                              <a class="btn btn-sm btn-primary" data-bs-toggle="modal" style="color:white;" data-bs-target="#Modallogdetail" log-id="'.$log['log_id'].'" onclick="get_details(this)" id="editbuton">Detay<i class="bi bi-pen"></i></a>                                                         

                              
                            </td></tr>';
        }else{
            $htmll .='<tr><td>'.$log['title_name'].'</td>
                          <td>'.$log['user_name'].'</td>
                          <td>'.$log['type_name'].'</td>
                          <td>'.$log['add_date'].'</td>
                          <td>Başarısız</td>
                          <td class="text-center">
                              <a class="btn btn-sm btn-primary" data-bs-toggle="modal" style="color:white;" data-bs-target="#Modallogdetail"  log-id="'.$log['log_id'].'" onclick="get_details(this)" id="detaybuton">Detay<i class="bi bi-pen"></i></a>                                                         
                            </td></tr>';
        }
    }
    if($sayfasayisi > 1):
      if(isset($_POST["page"])):
          if(is_numeric($_POST["page"])):
                $sayfa = $_POST["page"];
          else:
                $sayfa = 1;
          endif;
      else:
        $sayfa = 1;
      endif;

    $htmlp .='<div class="b-pagination-outer mt-5"><ul id="border-pagination">';
    if(isset($_POST["page"]) && $_POST["page"] > 1){
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa-1).'">«</a></li>';
        if($_POST["page"] > 3){
            $htmlp .='<li><a onclick="pagination(this)" page-id="1">1</a></li>';
            if($sayfa>4){
                $htmlp .='<li><a href="javascript:;" >...</a></li>';
            }
        }
    }
    for($i=$sayfa-2; $i<=$sayfa+2; $i++){
        if($i> 0 && $i<=$sayfasayisi){
            if($i == $sayfa){
                $htmlp .='<li><a href="javascript:;" class="active">'.$i.'</a></li>';
            }else{
                $htmlp .='<li><a onclick="pagination(this)" page-id="'.$i.'">'.$i.'</a></li>';
            }
        }
    }
    if($sayfa < $sayfasayisi-2){
        if($sayfa+3<$sayfasayisi){
            $htmlp .='<li><a href="javascript:;" >...</a></li>';
        }
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.$sayfasayisi.'">'.$sayfasayisi.'</a></li>';
        $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa+1).'">»</a></li>';
    }
    else{
        if($sayfa != $sayfasayisi){
            $htmlp .='<li><a onclick="pagination(this)" page-id="'.($sayfa+1).'">»</a></li>';
        }
    }
    $htmlp .='</ul></div>
                ';
            endif;
            $htmlp .='</div>';
    echo $htmll."*".$htmlp;

}


?>