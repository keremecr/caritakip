<?php require_once 'class.crud.php';
ob_start();
 ?>

<!DOCTYPE html>


<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Account settings</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
  </head>

  <body>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    } ?>

  <?php 
  $db=new crud();
  $veri=['id' => $_SESSION['id']];
  $user=$db->sorgukosullu("SELECT * FROM users u INNER JOIN timezones t ON u.timezone=t.timezone_id WHERE u.user_id=?",$veri);
  $countries=$db->sorgu("SELECT * FROM countries");
  $currency=$db->sorgu("SELECT * FROM currencies");
  foreach($user as $item){
    $name=$item['user_name'];
    $telefon=$item['phone_number'];
    $email=$item['email'];
    $address=$item['address'];
    $lang=$item['language'];
    $photo=$item['image'];
    $timezone=$item['timezone'];
    $user_currency=$item['currency'];
  }
  $timezones=$db->sorgu("SELECT * FROM timezones");

$isimarray=explode(" ",$name);
$ad=$isimarray[0];
$soyad=$isimarray[1];
$tkod=[];
$tarray=[];
for($i=0;$i<strlen($telefon);$i++){
  if($i>=0 && $i<2){
    array_push($tkod,$telefon[$i]);
  }
  else{
    array_push($tarray,$telefon[$i]);
  }
}
$tarray=implode("",$tarray);
$tkod=implode("",$tkod);

  ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <?php include 'navbar.php'; ?>
          <!-- Navbar -->


          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">

            <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>

               <?php } ?>
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Account Settings /</span> Account</h4>

              <div class="row">
                <div class="col-md-12">
                  <ul class="nav nav-pills flex-column flex-md-row mb-3">
                    <li class="nav-item">
                      <a class="nav-link active" href="javascript:void(0);"><i class="bx bx-user me-1"></i> Account</a>
                    </li>
                  </ul>
                  <div class="card mb-4">
                    <h5 class="card-header">Profile Details</h5>
                    <!-- Account -->
                    <div class="card-body">
                      <div class="d-flex align-items-start align-items-sm-center gap-4">
                        <img
                          src="<?php echo $photo; ?>"
                          alt="user-avatar"
                          class="d-block rounded"
                          height="100"
                          width="100"
                          id="uploadedAvatar"
                        />
                        <div class="button-wrapper">
                          <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                            <span class="d-none d-sm-block">Upload new photo</span>
                            <i class="bx bx-upload d-block d-sm-none"></i>
                            <input
                              type="file"
                              id="upload"
                              class="account-file-input"
                              hidden
                              accept="image/png, image/jpeg"
                            />
                          </label>
                          <button type="button" class="btn btn-outline-secondary account-image-reset mb-4">
                            <i class="bx bx-reset d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Reset</span>
                          </button>

                          <p class="text-muted mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                        </div>
                      </div>
                    </div>
                    <hr class="my-0" />
                    <div class="card-body">
                      <form id="formAccountSettings" method="POST" action="?pg=update">
                        <div class="row">
                          <div class="mb-3 col-md-6">
                            <label for="firstName" class="form-label">First Name</label>
                            <input
                              class="form-control"
                              type="text"
                              id="firstName"
                              name="firstname"
                              value="<?php echo $ad; ?>"
                              autofocus
                            />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="lastName" class="form-label">Last Name</label>
                            <input class="form-control" type="text" name="lastname" id="lastName" value="<?php echo $soyad; ?>" />
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="email" class="form-label">E-mail</label>
                            <input
                              class="form-control"
                              type="text"
                              id="email"
                              name="email"
                              value="<?php echo $email; ?>"
                              placeholder="john.doe@example.com"
                            />
                          </div>
                          
                          <div class="mb-3 col-md-6">
                            <label class="form-label" for="phoneNumber">Phone Number</label>
                            <div class="input-group input-group-merge">
                              <select class="form-select btn-sm" name="kod" id="kod" onchange="getresults(this)" required> 
                              <?php if($tkod=="90"){ ?>                                                  
                                <option value="90" selected>TR +90</option>
                                <option value="1">US +1</option>
                              <?php  }else{ ?>
                                <option value="90" >TR +90</option>
                                <option value="1" selected>US +1</option>
                             <?php } ?>                                      
                              </select>
                              
                                
                            
                              
                              <input
                                type="text"
                                id="phoneNumber"
                                name="phonenumber"
                                class="form-control"
                                value="<?php echo $tarray; ?>"
                              />
                            </div>
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address" placeholder="Address" value="<?php echo $address; ?>"/>
                          </div>
                          <div class="mb-3 col-md-6">
                            <label class="form-label" for="country">Country</label>
                            <select id="country" name="country" class="select2 form-select">
                              <?php foreach($countries as $country){ ?>
                                <option value="<?php echo $country; ?>" <?php if($country['country_name']==$usercountry){ echo 'selected';} ?>><?php echo $country['country_name']; ?></option>
                             <?php } ?>
                            </select>
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="language" class="form-label">Language</label>
                            <select id="language" name="language" class="select2 form-select">                          
                              <option value="İngilizce" <?php if($lang=="İngilizce"){echo 'selected';} ?>>English</option>
                              <option value="Türkçe" <?php if($lang=="Türkçe"){echo 'selected';} ?>>Türkçe</option>
                            </select>
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="timeZones" class="form-label">Timezone</label>
                            <select id="timeZones" name="timezone" class="select2 form-select">
                              <?php foreach($timezones as $time) { ?>
                                <option value="<?php echo $time['timezone_id']; ?>" <?php if($time['timezone_id']==$timezone){echo 'selected'; } ?> ><?php echo $time['timezone_name']; ?></option>
                            <?php  } ?>
                            </select>
                          </div>
                          <div class="mb-3 col-md-6">
                            <label for="currency" class="form-label">Currency</label>
                            <select id="currency"  name="currency" class="select2 form-select">
                              <?php foreach($currency as $curr) { ?>
                                <option value="<?php echo $curr['currency_id']; ?>" <?php if($curr['currency_id']==$user_currency){echo 'selected'; } ?> ><?php echo $curr['currency_name']; ?></option>
                            <?php  } ?>
                            </select>
                          </div>
                        </div>
                        <div class="mt-2">
                          <button type="submit" class="btn btn-primary me-2">Save changes</button>
                          <button type="reset" class="btn btn-outline-secondary">Cancel</button>
                        </div>
                      </form>
                    </div>
                    <!-- /Account -->
                  </div>
                  
                </div>
              </div>
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->


    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/pages-account-settings-account.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>

  <?php
  if(isset($_GET['pg'])){
    $pg=$_GET['pg'];
    if($pg=='update'){
      $firstname=$_POST['firstname'];
      $lastname=$_POST['lastname'];
      $name=$firstname." ".$lastname;
      $phone=$tkod." ".$_POST['phonenumber'];
      $sonuc=$db->userupdate($_POST,$phone,$name);
      if($sonuc['status']){
          $_SESSION['success_message']="Bilgiler başarıyla güncellendi.";
          ///////////////////////
                $log_summary = [
                    'post' => $_POST,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> 0,
                    'type'     => 'U',
                    'method'   => 'PUT',
                    'title'    => 'Kullanıcı güncelleme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $db->log($user_log);
                /////////////////////////
          header('Location: accountsettings.php');
        }
    }
  }




  ?>
</html>
