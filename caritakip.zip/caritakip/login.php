<?php 
require_once 'class.crud.php';
$db = new crud(); 
?>

<!DOCTYPE html>
<html
  lang="en"
  class="light-style customizer-hide"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Ajannet Giriş</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="assets/vendor/css/pages/page-auth.css" />
    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
  </head>

  <body>
    <!-- Content -->
<?php  if(!isset($_GET['pg'])) { ?>
    <div class="container-xxl">
      <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
          <!-- Register -->
          <div class="card">
            <div class="card-body">
              <?php  if(isset($_GET['err'])){
                        $err=$_GET['err'];                       
                         if($err=='43') { ?>
                            <div class="alert alert-danger" role="alert">
                                Böyle bir mail yok!
                            </div>
                        <?php }
                        else if($err=='44') { ?>
                            <div class="alert alert-danger" role="alert">
                                Kullanıcı adı ile şifre eşleşmemektedir.
                            </div>
                            <?php                          
                         }
                    } ?>
              <!-- /Logo -->
              <center><img src="images/logo.png" style="max-width: 230px"></center>
              <hr>
              <?php if(isset($_COOKIE['userlogin'])){
                $login=json_decode($_COOKIE['userlogin']);
              } ?>

              <form id="formAuthentication" class="mb-3" action="login.php?pg=login" method="POST">
                <div class="mb-3">
                  <label for="email" class="form-label">Email Adresiniz</label>
                  <input
                    type="text"
                    class="form-control"
                    <?php
                    if(isset($_COOKIE['userlogin'])){
                      echo 'value="'.$login->mail.'"';
                    }
                    else{
                      echo 'placeholder="Enter your email or username"';
                    }
                    ?>
                    id="email"
                    name="email"                    
                    autofocus
                  />
                </div>
                <div class="mb-3 form-password-toggle">
                  <div class="d-flex justify-content-between">
                    <label class="form-label" for="password">Şifreniz</label>
                  </div>
                  <div class="input-group input-group-merge">
                    <input
                      type="password"
                      id="password"
                      class="form-control"
                      <?php
                        if(isset($_COOKIE['userlogin'])){
                          echo 'value="'.$login->sifre.'"';
                        }
                        else{
                          echo 'placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7"';
                        }
                      ?>
                      name="pass"
                      aria-describedby="password"
                    />
                    <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                  </div>
                </div>
                <div class="mb-3">
                  <div class="form-check">
                    <input class="form-check-input" type="checkbox"
                    <?php if(isset($_COOKIE['userlogin'])){
                      echo 'checked';
                    } ?>
                     id="remember-me" name="rememberme" />
                    <label class="form-check-label" for="remember-me"> Beni Hatırla</label>
                  </div>
                </div>
                <div class="mb-3">
                  <button class="btn btn-primary d-grid w-100" type="submit">Giriş Yap</button>
                </div>
              </form>

            </div>
          </div>
          <!-- /Register -->
        </div>
      </div>
    </div>
    <?php } else{
    $pg=$_GET['pg'];
    if($pg=='login'){
      $email=$_POST["email"];
      $pass=$_POST['pass'];
      $mailsorgu=$db->mailquery($email);
      $rememberme=$_POST['rememberme'];
      $passgecici=$pass;
      if($mailsorgu){
        if(isset($_COOKIE['userlogin'])){
          $pass=md5(md5(md5(md5($pass))));
        }else{
          $pass=md5(md5(md5(md5($pass))));
        }
        $sifresorgu=$db->wwreadcount("users","email",$email,"password",$pass);
        if($sifresorgu){
          if(!empty($rememberme) AND empty($_COOKIE['userlogin'])){
            $userbilgiler=['mail' => $email, 'sifre' => $passgecici];
            setCookie("userlogin",json_encode($userbilgiler), time() + (86400 * 30));
          }else if(empty($rememberme) AND !empty($_COOKIE['userlogin'])){
            setCookie("userlogin",json_encode($userbilgiler), time() - (86400 * 30));
          }
          $sorgu=$db->wwread("users","email",$email,"password",md5(md5(md5(md5($passgecici)))));
            foreach($sorgu as $data){
              $_SESSION['id']=$data['user_id'];
              $_SESSION['name']=$data['user_name'];
              $_SESSION['email']=$data['email'];
              $_SESSION['type']=$data['type'];
            }
            $today=getdate();
            $tarih=$today['year']."-".$today['mon']."-".$today['mday']." ".$today['hours'].":".$today['minutes'].":".$today['seconds'];
            $values=['email' => $_POST["email"], 'pass' => $pass,'girilen_zaman' => $tarih, 'name' => $_SESSION['name']];
          ############################################################################################
          $log_summary = [
              'post' => $values,
          ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> 0,
              'type'     => 'O',
              'method'   => 'POST',
              'title'    => 'Başarılı Giriş',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          ############################################################################################
          header('Location: dashboard.php');
        }else{
          ############################################################################################
          $log_summary = [
              'post' => $_POST,
          ];
          $user_log = (object) [
              'user_id'  => 0,
              'company_id'=> 0,
              'type'     => 'O',
              'method'   => 'POST',
              'title'    => 'Hatalı Şifre Girişi',
              'response' => 'error',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          ############################################################################################
          header('Location: login.php?err=44'); //şifre yanlış
        }
      }
      else{
        ############################################################################################
        $log_summary = [
            'post' => $_POST,
        ];
        $user_log = (object) [
            'user_id'  => 0,
            'company_id'=> 0,
            'type'     => 'O',
            'method'   => 'POST',
            'title'    => 'Hatalı E-mail Girişi',
            'response' => 'error',
            'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
            'ip'       => $_SERVER['REMOTE_ADDR']
        ];        
        $db->log($user_log);
        ############################################################################################
        header('Location: login.php?err=43'); //böyle bir mail yok
      }
    }
  }
  ?>




  

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>