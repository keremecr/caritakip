<?php require_once 'class.crud.php';
ob_start();
 ?>

<!DOCTYPE html>


<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Kullanıcı Hareketleri</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>

    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
    <style type="text/css">
    .btn-light{
  background-color: white!important;
}

.page-header {
  text-align: center;
  font-size: 1.5em;
  font-weight: normal;
  border-bottom: 1px solid #ddd;
  margin: 30px 0
}
.b-pagination-outer {
  width: 100%;
  margin: 0 auto;
  text-align: center;
  overflow: hidden;
  display: flex
}
#border-pagination {
  margin: 0 auto;
  padding: 0;
  text-align: center
}
#border-pagination li {
  display: inline;

}
#border-pagination li a {
  display: block;
  text-decoration: none;
  color: #000;
  padding: 5px 10px;
  border: 1px solid #ddd;
  float: left;

}
#border-pagination li a {
  -webkit-transition: background-color 0.4s;
  transition: background-color 0.4s
}
#border-pagination li a.active {
  background-color: #696cff;
  color: #fff;
}
#border-pagination li a:hover:not(.active) {
  background: #ddd;
} 
    </style>
  </head>

  
  <?php 
  $db=new crud();
  if(isset($_GET['sayfa'])){
    $sayfa=$_GET['sayfa'];
  }
  else{
    $sayfa=1;
  }
$paginate=5;
$sayfa1=($sayfa*$paginate)-$paginate;
$logs=$db->sorgu("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id ORDER BY a.log_id ASC LIMIT $sayfa1, $paginate");
$clogs=$db->sorgucount("SELECT * FROM action_logs a INNER JOIN users u ON a.user_id=u.user_id INNER JOIN action_logs_titles t ON t.id=a.title_id INNER JOIN action_logs_types ty ON a.type_id=ty.id ORDER BY a.log_id");
$logtypes=$db->sorgu("SELECT * FROM action_logs_types");
$users=$db->sorgu("SELECT * FROM users");


$sayfasayisi=ceil($clogs/$paginate);

// 
//print_r($stmt);
//foreach($logs as $log){
//  $bilgi=json_decode($log['summary'],true);
//}
//echo "<hr>";









?>



                      

  <body>
    <?php 
    $type=$_SESSION['type'];
    if($type!="Admin"){
      header('Location: hata.php');
      exit();
    } ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">

          <?php include 'navbar.php'; ?>

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              

              <div class="card">
                <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>

               <?php } ?>
                <h5 class="card-header">Kullanıcı Hareketleri</h5>
                <div class="row m-2">
                    <div class="col-md-3">
                      <label style="padding-bottom:5px;">Başlangıç Tarihi</label>
                      <input  type="datetime-local" class="form-control btn-sm" name="start_date" id="start_date" onchange="getresults()">
                    </div>
                    <div class="col-md-3">
                      <label style="padding-bottom:5px;">Bitiş Tarihi</label>
                      <input  type="datetime-local" class="form-control btn-sm" name="end_date" id="end_date" onchange="getresults()">
                    </div>
                    <div class="col-md-3">
                      <label style="padding-bottom:5px;">İşlem Türü</label>
                      <select class="form-select btn-sm" name="log_type" id="log_type" onchange="getresults()">
                         <option value="0">Tümü</option>
                        <?php foreach($logtypes as $type){ ?>
                          <option value="<?php echo $type['id']; ?>"><?php echo $type['type_name']; ?></option>
                      <?php  } ?>                                    
                        </select>
                    </div>
                    <div class="col-md-3">
                      <label style="padding-bottom:5px;">İşlemi Yapan Kullanıcı</label>
                      <select class="form-select btn-sm" name="user_name" id="user_name" onchange="getresults()">
                         <option value="0">Tümü</option>
                        <?php foreach($users as $user){ ?>
                          <option value="<?php echo $user['user_id']; ?>"><?php echo $user['user_name']; ?></option>
                      <?php  } ?>                                    
                        </select>
                    </div>
                </div>
                  
                <style type="text/css">
                  td{
                    font-size: 13px;
                  }                  
                </style>
                <div class="table-responsive text-nowrap mt-5">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Yapılan İşlem</th>
                        <th>İşlemi Yapan Kullanıcı</th>
                        <th>İşlem Türü</th>
                        <th>İşlem Tarihi</th>
                        <th>Sonuç</th>
                        <th>İşlemler</th>
                      </tr>
                    </thead>
                    <tbody id="searchresults" class="table-border-bottom-0">
                      <?php foreach($logs as $log){ ?>
                        <tr>
                          <td><?php echo $log['title_name']; ?></td>
                          <td><?php echo $log['user_name']; ?></td>
                          <td><?php echo $log['type_name']; ?></td>
                          <td><?php echo $log['add_date']; ?></td>
                          <td class="text-center" ><?php if($log['response']==17){ ?>
                            <p>Başarılı</p>
                         <?php }else{ ?>
                            <p>Başarısız</p>
                         <?php }?>
                            
                          </td>
                          <?php if($_SESSION['type']=="Admin"){ ?>
                            <td class="text-center">
                              <a class="btn btn-sm btn-primary" data-bs-toggle="modal" style="color:white;" data-bs-target="#Modallogdetail"  log-id="<?php echo $log['log_id']; ?>" onclick="get_details(this)" id="detaybuton">Detay<i class="bi bi-pen"></i></a>                                                         
                            </td>
                          </tr>
                            

                            

                                
                         <?php } 
                      } ?>                         
                        

                        
                      
                    </tbody>
                  </table>

              
                </div>
              </div>

              <?php 

                if($sayfasayisi > 1):
                  if(isset($_GET["sayfa"])):
                      if(is_numeric($_GET["sayfa"])):
                            $sayfa = $_GET["sayfa"];
                      else:
                            $sayfa = 1;
                      endif;
                  else:
                    $sayfa = 1;
                  endif  
                  ?>
              <div id="pagiajax">
                <div class="b-pagination-outer mt-5">
                  <ul id="border-pagination">
                    <?php 
                     if(isset($_GET["sayfa"]) && $_GET["sayfa"] > 1):
                        ?>
                         <li><a class="log_pagination" id="<?php echo $sayfa-1; ?>" href="javascript:;">«</a></li>
                         <?php
                         if($_GET["sayfa"] > 3):
                          ?>
                             <li><a class="log_pagination" href="javascript:;" id="1" >1</a></li>

                             <?php if($sayfa>4): ?>
                             <li><a href="javascript:;" >...</a></li>
                          <?php endif;
                         endif; 
                     endif;
                     for($i=$sayfa-2; $i<=$sayfa+2; $i++): 

                         if($i> 0 && $i<=$sayfasayisi):
                                if($i == $sayfa):
                                    ?>
                                   <li><a href="javascript:;" class="active"> <?php echo $i; ?></a></li>
                                <?php
                                else:
                                    ?>
                                     <li><a class="log_pagination" href="javascript:;" id="<?php echo $i; ?>" > <?php echo $i; ?></a></li>
                                <?php
                                endif;
                            endif;
                        
                   endfor;

                  if($sayfa < $sayfasayisi-2):
                            if($sayfa+3<$sayfasayisi):
                              ?>
                              <li><a href="javascript:;" >...</a></li>
                              <?php
                            endif;  
                            ?>
                             
                             <li><a class="log_pagination"  href="javascript:;" id="<?php echo $sayfasayisi; ?>" ><?php echo $sayfasayisi; ?></a></li>
                            <li><a  class="log_pagination"  href="javascript:;" id="<?php echo $sayfa+1; ?>">»</a></li>
                        <?php
                    else:
                          if($sayfa != $sayfasayisi):

                          ?>
                           <li><a class="log_pagination" href="javascript:;" id="<?php echo $sayfa+1; ?>">»</a></li><?php
                         endif;
                        endif;  

                 ?>
                  </ul> 
                </div> 
                  <?php
                endif;  
               ?>
              </div> 
              <input type="hidden" id="countlog" value="<?php echo $sayfasayisi; ?>">



          
              <!-- Layout Demo -->
              
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>

          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <!-- / Layout wrapper -->



    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <div class="modal fade" id="Modallogdetail" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Hareket Detayları</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <div id="detailslog">
                              </div>
                              
                            <input type="hidden" id="customer_editid" name="customer_id">
                            <div class="modal-footer">
                              <button type="button" id="closeupdate" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closingupdate()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </div>
                        </div>
                      </div>

                      
    
  </body>

  <?php
    if(isset($_GET['pg'])){
      $pg=$_GET['pg'];
    }
    



  ?>

</html>
<script src="assets/js/main.js"></script>
<script src="assets/js/ui-toasts.js"></script>

<script>

function closinginsert(){
  $('#Modalinsertcustomer').modal('toggle');
}
function closingupdate(){
  $('#Modaleditcustomer').modal('toggle');
}
function closingdelete(){
  $('#Modaldeletecustomer').modal('toggle');
}


$(document).on('click', '.log_pagination', function(){
        var page = $(this).attr("id");
        getresults(page);
    });

function get_details(attr){
  var log_id=$(attr).attr('log-id');
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{log_id:log_id},
    dataType: 'html',
    success: function(datam){
      $('#detailslog').html(datam);
    }
  });
}

function getresults(page=1){
  var user_name=$('#user_name').val();
  var log_type=$('#log_type').val();
  var start_date=$('#start_date').val();
  var end_date=$('#end_date').val();
  console.log(log_type);
  if(log_type==""){
    console.log("bunun içi boş");
  }
  var logpaginate=1;
  var sayfasayisi=$('#countlog').val();
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{page:page, logpaginate:logpaginate, sayfasayisi:sayfasayisi, user_name:user_name, log_type:log_type, start_date:start_date, end_date:end_date},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#searchresults').html(myArray[0]);
      $('#pagiajax').html(myArray[1]);
    }
  });
}

function pagination(attr){
  var user_name=$('#user_name').val();
  var log_type=$('#log_type').val();
  var start_date=$('#start_date').val();
  var end_date=$('#end_date').val();
  var page=$(attr).attr('page-id');
  var sayfasayisi=$('#countlog').val();
  var logpaginate=1;
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{page:page,logpaginate:logpaginate, sayfasayisi:sayfasayisi, user_name:user_name, log_type:log_type, start_date:start_date, end_date:end_date},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#searchresults').html(myArray[0]);
      $('#pagiajax').html(myArray[1]);
    }
  });
}


</script>


<script src="assets/js/main.js"></script>
<script src="assets/js/ui-toasts.js"></script>

