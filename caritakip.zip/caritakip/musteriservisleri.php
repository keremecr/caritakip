<?php require_once 'class.crud.php';
ob_start();
 ?>

<!DOCTYPE html>


<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Modül Listesi</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/bootstrap-select.min.js"></script>

    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>

        <style type="text/css">
.bootstrap-select {
  width: 100%!important;
  border: 1px solid #ccc!important;
  border-radius: 0.375rem!important;
  background-color: white!important;
}     
.btn-light{
  background-color: white!important;
}

.page-header {
  text-align: center;
  font-size: 1.5em;
  font-weight: normal;
  border-bottom: 1px solid #ddd;
  margin: 30px 0
}
.b-pagination-outer {
  width: 100%;
  margin: 0 auto;
  text-align: center;
  overflow: hidden;
  display: flex
}
#border-pagination {
  margin: 0 auto;
  padding: 0;
  text-align: center
}
#border-pagination li {
  display: inline;

}
#border-pagination li a {
  display: block;
  text-decoration: none;
  color: #000;
  padding: 5px 10px;
  border: 1px solid #ddd;
  float: left;

}
#border-pagination li a {
  -webkit-transition: background-color 0.4s;
  transition: background-color 0.4s
}
#border-pagination li a.active {
  background-color: #696cff;
  color: #fff;
}
#border-pagination li a:hover:not(.active) {
  background: #ddd;
}     
        </style>
  </head>

  
  <?php 
  $dbase=new crud();
  $musteriler=$dbase->read("customers");
  $dbb=new crud();
  $services=$dbb->findcustomerservices();
  $veri=['is_delete' => 0];
  if(isset($_GET['sayfa'])){
    $sayfa=$_GET['sayfa'];
  }
  else{
    $sayfa=1;
  }

  $paginate=5;
  $sayfa1=($sayfa*$paginate)-$paginate;
  $services=$dbb->sorgukosullu("SELECT * ,GROUP_CONCAT(v.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(s.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(s.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(s.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(s.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services s INNER JOIN customer_types t ON s.customer_type_id=t.customer_type_id INNER JOIN customers c ON s.customer_id=c.customer_id INNER JOIN users u ON s.user_id=u.user_id INNER JOIN services v ON s.service_id=v.service_id WHERE s.customer_service_is_delete=? GROUP BY c.customer_id ORDER BY s.customer_id ASC LIMIT $sayfa1, $paginate",$veri);
  $cservisler=$dbb->sorgukosullucount("SELECT * ,GROUP_CONCAT(v.service_name SEPARATOR ',') AS servisname, GROUP_CONCAT(s.customer_service_is_delete SEPARATOR ',') AS servisdurumu, GROUP_CONCAT(s.quantity SEPARATOR ',') AS miktar, GROUP_CONCAT(s.service_total_tr SEPARATOR ',') AS servisucrettr, GROUP_CONCAT(s.service_total_usd SEPARATOR ',') AS servisucretusd FROM customer_services s INNER JOIN customer_types t ON s.customer_type_id=t.customer_type_id INNER JOIN customers c ON s.customer_id=c.customer_id INNER JOIN users u ON s.user_id=u.user_id INNER JOIN services v ON s.service_id=v.service_id WHERE s.customer_service_is_delete=? GROUP BY c.customer_id ORDER BY s.customer_id",$veri);
 
  $sayfasayisi=ceil($cservisler/$paginate);
  $servisler=$dbb->read("services");
  ?>

                      

  <body>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    } ?>

  <div class="modal fade" id="Modalinsertservice" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Modül Ekle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>

                            <div class="modal-body">
                              <form action="?pg=insert" method="POST">
                                <div class="row">
                                  <div class="col mb-3">
                                    <label for="nameSmall" class="form-label">Müşteri Adı</label>
                                    <select class="form-select" name="customer_id" id="insertmusteri" onchange="getservice(this)" required>
                                      <option value="0" selected>Müşteri Seç</option>
                                      <?php foreach($musteriler as $musteri) { ?>
                                        <option value="<?php echo $musteri['customer_id']; ?>"><?php echo $musteri['customer_name']; ?></option>
                                     <?php } ?>
                                        
                                    </select>
                                  </div>
                                </div> 

                              <div class="row">
                                <div class="col mb-12">
                                  <label for="nameSmall" class="form-label">Modül Adı</label>
                                  <div id="insertservis"></div>
                                </div>
                              </div>
                              <div id="eklemeadetleri"></div>
                              <input type="hidden" id="counteklenecek" name="inputsayisi">

                            </div>                            
                            <div class="modal-footer">
                              <button type="button" id="closeinsert" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closinginsert()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>

<script type="text/javascript">
$(document).ready(function() {
    jQuery(".selectpickers").selectpicker();
})  
</script>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    } ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">

          <?php include 'navbar.php'; ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              

              <div class="card">
                <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>

               <?php } ?>
                <h5 class="card-header">Müşteri Detaylı Cari Listesi</h5>
                <div class="row m-2">
                    <?php if($_SESSION['type']=="Admin"){ ?>
                    <div class="col-md-2">
                        <a class="btn btn-sm btn-primary text-white" data-bs-toggle="modal" data-bs-target="#Modalinsertservice"><i class="fa fa-plus"></i>Modül Ekle</a>
                    </div>
                    <?php } ?>
                    <div class="col-md-3">
                      <div class="form-group">                   
                        <input type="text" class="form-control btn-sm" id="search" onkeyup="getresults(this)" placeholder="Müşteri ara..">
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group">
                        <select class="form-select btn-sm" name="customer_id" id="servisfiltre" onchange="getresults(this)" required>
                          <option value="0">Modül Seç</option>
                          <?php foreach($servisler as $servis){ ?>                    
                            <option value="<?php echo $servis['service_id']; ?>"><?php echo $servis['service_name']; ?></option>
                        <?php  } ?>                                      
                        </select>
                      </div>
                    </div>
                    <div class="col-md-2">
                      
                        <button type="submit" class="btn btn-info btn-sm" onclick="temizle()">Temizle</button>
                    </div>
                </div>
                  <hr>
                
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Müşteri Adı</th>
                        <th>Modül Adı</th>     
                        <th>Miktar</th>
                        <th>Modül Ücreti TL</th>
                        <th>Modül Ücreti USD</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody id="searchresults" class="table-border-bottom-0">
                      <?php foreach($services as $service){ ?>
                        <tr>
                          <td><?php echo $service['customer_name']; ?></td>
                          <td><?php echo $service['servisname']; ?></td>        
                          <td><?php echo $service['miktar']; ?></td>
                          <td><?php echo $service['servisucrettr']; ?></td>
                          <td><?php echo $service['servisucretusd']; ?></td>
                          <?php if($_SESSION['type']=="Admin"){ ?>
                            <td>
                              <a class="btn btn-sm btn-primary" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaleditservice" id="buton" customer-type-id="<?php echo $service['customer_type_id']; ?>" customer-id="<?php echo $service['customer_id']; ?>" service-name="<?php echo $service['service_name']; ?>" service-id="<?php echo $service['customer_service_id']; ?>" onclick="getdataforedit(this)" >Düzenle<i class="bi bi-pen"></i></a>                                                         

                              <a class="btn btn-sm btn-danger" style="color:white;" data-bs-toggle="modal" data-bs-target="#Modaldeleteservice" id="silmebutonu" customer-id="<?php echo $service['customer_id']; ?>" delete-id="<?php echo $service['customer_service_id']; ?>" onclick="getdata(this)">Sil<i class="bi bi-trash"></i></a>
                            </td>
                          </tr>
                            

                            

                                
                         <?php } 
                      } ?>                         
                        

                        
                      
                    </tbody>
                  </table>

              
                </div>
              </div>

              
               <?php 

                if($sayfasayisi > 1):
                  if(isset($_GET["sayfa"])):
                      if(is_numeric($_GET["sayfa"])):
                            $sayfa = $_GET["sayfa"];
                      else:
                            $sayfa = 1;
                      endif;
                  else:
                    $sayfa = 1;
                  endif  
                  ?>
              <div id="pagiajax">
                <div class="b-pagination-outer mt-5">
                  <ul id="border-pagination">
                    <?php 
                     if(isset($_GET["sayfa"]) && $_GET["sayfa"] > 1):
                        ?>
                         <li><a class="musteri_pagination" id="<?php echo $sayfa-1; ?>" href="javascript:;">«</a></li>
                         <?php
                         if($_GET["sayfa"] > 3):
                          ?>
                             <li><a class="musteri_pagination" href="musteriler.php?sayfa=1" >1</a></li>

                             <?php if($sayfa>4): ?>
                             <li><a href="javascript:;" >...</a></li>
                          <?php endif;
                         endif; 
                     endif;
                     for($i=$sayfa-2; $i<=$sayfa+2; $i++): 

                         if($i> 0 && $i<=$sayfasayisi):
                                if($i == $sayfa):
                                    ?>
                                   <li><a href="javascript:;" class="active"> <?php echo $i; ?></a></li>
                                <?php
                                else:
                                    ?>
                                     <li><a class="musteri_pagination" href="javascript:;" id="<?php echo $i; ?>" > <?php echo $i; ?></a></li>
                                <?php
                                endif;
                            endif;
                        
                   endfor;

                  if($sayfa < $sayfasayisi-2):
                            if($sayfa+3<$sayfasayisi):
                              ?>
                              <li><a href="javascript:;" >...</a></li>
                              <?php
                            endif;  
                            ?>
                             
                             <li><a class="musteri_pagination"  href="javascript:;" id="<?php echo $sayfasayisi; ?>" ><?php echo $sayfasayisi; ?></a></li>
                            <li><a  class="musteri_pagination"  href="javascript:;" id="<?php echo $sayfa+1; ?>">»</a></li>
                        <?php
                    else:
                          if($sayfa != $sayfasayisi):

                          ?>
                           <li><a class="musteri_pagination" href="javascript:;" id="<?php echo $sayfa+1; ?>">»</a></li><?php
                         endif;
                        endif;  

                 ?>
                  </ul> 
                </div> 
                  <?php
                endif;  
               ?>
              </div> 
            
          
              <!-- Layout Demo -->
              
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>

          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <!-- / Layout wrapper -->

    <div class="modal fade" tabindex="-1" id="Modaldeleteservice" role="dialog" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <form action="?pg=delete" method="POST">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title">Lütfen silmek istediğiniz modülleri seçiniz.</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                      <div id="silmedivi"></div>
                                      
                                    </div>
                                    <input type="hidden" id="servicedeleteid" name="customer_id">
                                    <input type="hidden" id="servicesilmeid" name="cservice_id">
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" id="closing" data-bs-dismiss="modal" aria-label="Close">Vazgeç</button>
                                      <button type="submit" class="btn btn-primary">Sil</button>
                                    </div>
                                    </form>
                                  </div>
                                </div>
                            </div>

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <div class="modal fade" id="Modaleditservice" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <form action="?pg=update" method="POST">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Modül Güncelle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div id="guncellememodali">
                             </div>
                            <input type="hidden" id="serviceupdateid" name="customer_id">
                            <input type="hidden" id="inputsayisi" name="inputsayisi">
                            <div class="modal-footer">
                              <button type="button"  class="btn btn-outline-secondary" data-bs-dismiss="modal" aria-label="Close">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>

    
  </body>

  <?php
    if(isset($_GET['pg'])){
      $pg=$_GET['pg'];
      if($pg=='insert'){
        if($_POST['service_name']==0){
          $_SESSION['error_message']="Modül boş geçilemez";
          header('Location: musteriservisleri.php');
          exit;
        }
        if($_POST['customer_id']==0){
          $_SESSION['error_message']="Müşteri boş geçilemez";
          header('Location: musteriservisleri.php');
          exit;
        }
        $negatif=0;
        $adeterror=0;
        $db=new crud();
        for($i=1;$i<=$_POST['inputsayisi'];$i++){
          if($_POST['total_tr_'.$i.'']<0 || $_POST['total_usd_'.$i.'']<0){
            $negatif+=1;
          }
          if($_POST['adet_'.$i.'']<=0){
            $adeterror+=1;
          }
        }
        if($negatif>0){
          $_SESSION['error_message']="Negatif değer girilemez";
          header('Location: musteriservisleri.php');
          exit;
        }
        if($adeterror>0){
          $_SESSION['error_message']="Geçerli bir adet girin";
          header('Location: musteriservisleri.php');
          exit;
        }
        $sonuc=$db->insertcustomerservice($_POST);
        if($sonuc['status']){
          $_SESSION['success_message']="Modül başarıyla kaydedildi.";
          header('Location: musteriservisleri.php');
        }
        else{
          $_SESSION['error_message']="Kayıt başarısız";
          header('Location: musteriservisleri.php');
        }
      }
      else if($pg=='update'){
        $db=new crud();
        $inputsayisi=$_POST['inputsayisi']-1;
        $adeterror=0;
        $negatif=0;
        for($i=1;$i<=$inputsayisi;$i++){
          if($_POST['total_tr_'.$i.'']<0 || $_POST['total_tr_'.$i.'']<0){
            $negatif+=1;
          }
          if($_POST['adet_'.$i.'']<=0){
            $adeterror+=1;
          }
        }
        if($negatif>0){
          $_SESSION['error_message']="Negatif değer girilemez";
          header('Location: musteriservisleri.php');
          exit;
        }
        if($adeterror>0){
          $_SESSION['error_message']="Geçerli bir adet girin";
          header('Location: musteriservisleri.php');
          exit;
        }
        $sonuc=$db->updatecustomerservice($_POST);
        if($sonuc['status']){
          $_SESSION['success_message']="Modül başarıyla güncellendi.";
          header('Location: musteriservisleri.php');
        }
        else{
          $_SESSION['error_message']="Güncelleme başarısız";
          header('Location: musteriservisleri.php');
        }
      }
      else if($pg=='delete'){
        $db=new crud();
        $sonuc=$db->updatestatuscservices($_POST);
        if($sonuc['status']){
          $_SESSION['success_message']=" Modül başarıyla silindi.";
          $log_summary = [
                    'post' => $_POST,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> $_POST['customer_id'],
                    'type'     => 'D',
                    'method'   => 'DELETE',
                    'title'    => 'Müşteri silme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $db->log($user_log);
          header('Location: musteriservisleri.php');
        }
        else{
          $_SESSION['error_message']="Silme başarısız";
          header('Location: musteriservisleri.php');
        }
      }
      else if($pg=='temizle'){
        header('Location: musteriservisleri.php');
      }
    }



  ?>

</html>
<script src="assets/js/main.js"></script>
<script src="assets/js/ui-toasts.js"></script>

<script>

function closinginsert(){
  $('#Modalinsertservice').modal('toggle');
}
function closingupdate(){
  $('#Modaleditservice').modal('toggle');
}
function closingdelete(){
  $('#Modaldeleteservice').modal('toggle');
}

</script>

<script>
function get_customer(attr){
  var customer_type = $('#inserttip').val();
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{customer_type:customer_type},
    dataType: 'html',
    success: function(datam){
      $('#insertmusteri').html(datam);
    }
  });
}

function getdataforedit(attr){
  var customer_id=$(attr).attr('customer-id');
  var service_id=$(attr).attr('service-id');
  var servis=$('#servisfiltre').val();
  $('#serviceupdateid').val(customer_id);
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{serviceforedit:customer_id, servis:servis, service_id:service_id},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#inputsayisi').val(myArray[1]);
      $('#guncellememodali').html(myArray[0]);
    }
  });
}


function getdata(attr){
  var customer_id=$(attr).attr('customer-id');
  var service_id=$(attr).attr('delete-id');
  $('#servicedeleteid').val(customer_id);
  $('#servicesilmeid').val(service_id);
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{customerfordelete:customer_id},
    dataType: 'html',
    success: function(datam){
      $('#silmedivi').html(datam);
    }
  });
}

function getservice(attr){
  var musteriinsertid=$('#insertmusteri').val();
  var html='';
  $('#insertservis').html(html);
  $('#eklemeadetleri').html(html);
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{musteriinsertid:musteriinsertid},
    dataType: 'html',
    success: function(datam){
      $('#insertservis').html(datam);
    }
  });

}

function getresults(page=1){
  var inputname=$('#search').val();
  var inputservis=$('#servisfiltre').val();
  if(inputname.length<3){
    inputname='';
  }
  console.log(inputname);
  console.log(inputservis);
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{inputname:inputname, inputservis:inputservis, page:page},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#searchresults').html(myArray[0]);
      $('#pagiajax').html(myArray[1]);

    }
  });
}

   $(document).on('click', '.musteri_pagination', function(){
        var page = $(this).attr("id");
        getresults(page)
    });
//

function getbilgi(attr){
  if($('#coklusecim').val()){
    var alinanservisler=$('#coklusecim').val();
    var servissayisi=alinanservisler.length; 
  }
  else{
    var servissayisi=0; 
  }  
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{servissayisi:servissayisi, alinanservisler:alinanservisler},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#eklemeadetleri').html(myArray[0]);
      $('#counteklenecek').val(myArray[1]);
    }
  });
}

function temizle(){
  var inputname='';
  var sayi=0;
  var page=1;
  $('#search').val(inputname);
  $('#servisfiltre').val(sayi);
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{inputname:inputname, inputservis:sayi, page:page},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#searchresults').html(myArray[0]);
      $('#pagiajax').html(myArray[1]);
    }
  });
}

function pagination(attr){
  var page=$(attr).attr('page-id');
  var inputname=$('#search').val();
  var inputservis=$('#servisfiltre').val();
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{inputname:inputname, inputservis:inputservis, page:page},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#searchresults').html(myArray[0]);
      $('#pagiajax').html(myArray[1]);
    }
  });
}

</script>