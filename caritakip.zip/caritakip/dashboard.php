
<?php require_once 'class.crud.php';
ob_start();
 ?>

<!DOCTYPE html>


<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Ana Sayfa</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    
    <script src="assets/js/config.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  </head>

  <script>
    function get_service(attr){
      console.log("ben geldim");
        var customer_type_id = $('#musteritipi').val();
        console.log(customer_type_id);
        $.ajax({
            method:'post',
            url: 'ajax.php',
            data:{customer_type_id:customer_type_id},
            dataType: 'html',
            success: function(datam){
                $('#servis').html(datam);
            }
        });
    }
  </script>
  <?php 
  $db=new crud();
  $musteritipleri=$db->read("customer_types");
  
  ?>

  <body>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    } ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <?php include 'navbar.php'; ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">

            <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>
            <!-- Content -->
            <?php } ?>
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-md-3">
                    <form action="" method="get">
                      <input type="hidden" name="pg" value="firstsorgu">
                    <div class="mb-3">
                        <label for="defaultSelect" class="form-label">Müşteri Tipi</label>
                        <select  class="form-select" name="musteritipi" id="musteritipi" onchange="get_service(this)">
                          <option value="0">Seçiniz</option>
                          <?php foreach($musteritipleri as $musteritipi){ ?>
                            <option value="<?php echo $musteritipi['customer_type_id'];?>" customertypeid="<?php echo $musteritipi['customer_type_id']; ?>" ><?php echo $musteritipi['customer_type_name']; ?> </option>
                          <?php } ?>
                        </select>
                    </div>                    
                </div>
                <div class="col-md-3">
                  <div class="mb-3">
                          <label for="defaultSelect" class="form-label">Modül Seçin</label>
                          <select class="form-select" name="servis" id="servis">
                            <option value="0">Önce müşteri tipi</option>
                          </select>
                    </div>  
                </div>
                <div style="margin-top:22px;" class="col-md-3">
                  <label class="form-label"><br><br></label>
                <button type="submit" class="btn btn-primary">Listele</button>
                </form>
                </div>
              </div>

              <?php
              if(isset($_GET['au'])){
                $au=$_GET['au'];
                if($au=='logout'){
                  session_destroy();
                  header('Location: login.php');
                  ob_end_flush();
                }
              }                                                                    
              else if(isset($_GET['pg'])){
                $pg=$_GET['pg'];
                if($pg=='firstsorgu'){
                  $db=new crud();
              $cservices=$db->findservicequery($_GET['musteritipi'],$_GET['servis']);
              ?>

              <div class="card">
                <h5 class="card-header">Müşteri Modül Listesi</h5>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Müşteri Adı</th>
                        <th>Modül Adı</th>
                        <th>Müşteri Tipi</th>
                        <th>Adet</th>
                        <th>Ekleyen Kullanıcı</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                      <?php foreach($cservices as $cservice){ ?>
                        <tr>
                          <td><?php echo $cservice['customer_name']; ?></td>
                          <td><?php echo $cservice['service_name']; ?></td>
                          <td><?php echo $cservice['customer_type_name']; ?></td>
                          <td><?php echo $cservice['quantity']; ?></td>
                          <td><?php echo $cservice['user_name']; ?></td>
                          <?php if($cservice['is_delete']==0){ ?>
                            <td>Aktif</td>
                          <?php  } else{ ?>
                            <td>Pasif</td>
                          <?php } ?>
                          <?php if($_SESSION['type']=="Admin"){ ?>
                          <td class="text-center">
                            <div class="dropdown">
                              <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                <i class="bx bx-dots-vertical-rounded"></i>
                              </button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" cservice-id="<?php echo $cservice['customer_service_id']; ?>" onclick="editcservice(this)" data-bs-toggle="modal"  data-bs-target="#Modaleditcservice"
                                  ><i class="bx bx-edit-alt me-2"></i> Edit</a
                                >
                                <a class="dropdown-item" cservice-id="<?php echo $cservice['customer_service_id']; ?>" onclick="deletecservice(this)" data-bs-toggle="modal"  data-bs-target="#Modaldeletecservice"
                                  ><i class="bx bx-trash me-2"></i> Delete</a
                                >
                              </div>
                            </div>
                          </td>
                        <?php } ?>                          
                        </tr>
                        
                     <?php } ?>
                     </tbody>
                  </table>
                   <?php  }else if($pg=='update'){
                      $cservice_id=$_POST['cservice_id'];
                      $db=new crud();
                      $sonuc=$db->updatecservicebyid($cservice_id,$_POST);
                      if($sonuc['status']){
                        $_SESSION['success_message']=" Müşteri servisi başarıyla güncellendi.";
                        header('Location: dashboard.php');
                      }
                      else{
                        $_SESSION['error_message']="Güncelleme başarısız";
                        header('Location: dashboard.php');
                      }
                     }else if($pg='delete'){
                        $id=$_POST['cservice_id'];
                        $db=new crud();
                        $sonuc=$db->updatestatus("customer_services","customer_service_id","customer_service_is_delete",$id);
                        if($sonuc['status']){
                          $_SESSION['success_message']=" Müşteri servisi başarıyla silindi.";
                          header('Location: dashboard.php');
                        }
                        else{
                          $_SESSION['error_message']="Silme başarısız";
                          header('Location: dashboard.php');
                        }
                      } ?>
                      
                    

              
                </div>
              </div>

           <?php }
            ?>
              <!-- Layout Demo -->
              
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>

          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <!-- / Layout wrapper -->
      <div class="modal fade" id="Modaleditcservice" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Müşteri Servisi Güncelle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <form action="?pg=update" method="POST">
                              <div id="cserviceeditdiv"></div>                                 
                            </div>
                            <input type="hidden" id="cservice" name="cservice_id">
                            <div class="modal-footer">
                              <button type="button" id="closeupdate" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closingupdate()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>


                  <div class="modal fade" tabindex="-1" id="Modaldeletecservice" role="dialog" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <form action="?pg=delete" method="POST">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title">Uyarı</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                        
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <p>Silmek istediğinize emin misiniz?</p>
                                    </div>
                                    <input type="hidden" id="cservice_deleteid" name="cservice_id">
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" id="closing" data-dismiss="modal" onclick="closingdelete()">Vazgeç</button>
                                      <button type="submit" class="btn btn-primary">Sil</button>
                                    </div>
                                    </form>
                                  </div>
                                </div>
                            </div>


    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    
  </body>

</html>
<script src="assets/js/main.js"></script>

<script>
  function editcservice(attr){
    var cservice_id=$(attr).attr('cservice-id');
    $('#cservice').val(cservice_id);
    $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{cserviceedit:cservice_id},
    dataType: 'html',
    success: function(datam){
      $('#cserviceeditdiv').html(datam);
    }
  });
  }

  function deletecservice(attr){
    var cservice_id=$(attr).attr('cservice-id');
    $('#cservice_deleteid').val(cservice_id);
  }

  function closingupdate(){
  $('#Modaleditcservice').modal('toggle');
  }
  function closingdelete(){
  $('#Modaldeletecservice').modal('toggle');
  }



</script>
