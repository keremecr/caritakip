<?php require_once 'class.crud.php';
ob_start();
 ?>

<!DOCTYPE html>


<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Müşteri Listesi</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="assets/js/config.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <style type="text/css">
.bootstrap-select {
  width: 100%!important;
  border: 1px solid #ccc!important;
  border-radius: 0.375rem!important;
  background-color: white!important;
}     
.btn-light{
  background-color: white!important;
}

.page-header {
  text-align: center;
  font-size: 1.5em;
  font-weight: normal;
  border-bottom: 1px solid #ddd;
  margin: 30px 0
}
.b-pagination-outer {
  width: 100%;
  margin: 0 auto;
  text-align: center;
  overflow: hidden;
  display: flex
}
#border-pagination {
  margin: 0 auto;
  padding: 0;
  text-align: center
}
#border-pagination li {
  display: inline;

}
#border-pagination li a {
  display: block;
  text-decoration: none;
  color: #000;
  padding: 5px 10px;
  border: 1px solid #ddd;
  float: left;

}
#border-pagination li a {
  -webkit-transition: background-color 0.4s;
  transition: background-color 0.4s
}
#border-pagination li a.active {
  background-color: #696cff;
  color: #fff;
}
#border-pagination li a:hover:not(.active) {
  background: #ddd;
}     
        </style>
  </head>

  
  <?php 
  $dbase=new crud();
  $musteriler=$dbase->findcustomers();
  $musteritipleri=$dbase->read("customer_types");
  if(isset($_GET['sayfa'])){
    $sayfa=$_GET['sayfa'];
  }
  else{
    $sayfa=1;
  }
$paginate=5;
$sayfa1=($sayfa*$paginate)-$paginate;
$veri=['is_delete' => 0];
$customers=$dbase->sorgukosullu("SELECT * FROM customers c INNER JOIN customer_types t ON c.customer_type_id=t.customer_type_id  INNER JOIN users u ON c.user_id=u.user_id WHERE c.customer_is_delete=? ORDER BY customer_id ASC LIMIT $sayfa1, $paginate",$veri);
$ccustomer=$dbase->sorgukosullucount("SELECT * FROM customers c INNER JOIN customer_types t ON c.customer_type_id=t.customer_type_id  INNER JOIN users u ON c.user_id=u.user_id WHERE c.customer_is_delete=? ORDER BY customer_id",$veri);
$sayfasayisi=ceil($ccustomer/$paginate);
  ?>
  <div class="modal fade" id="Modalinsertcustomer" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Müşteri Ekle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <form action="?pg=insert" method="POST">
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Adı</label>
                                  <input type="text"  name="customer_name" class="form-control" placeholder="Müşteri adı girin.." required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Tipi</label>
                                  <select class="form-select" name="customer_type_id" id="inserttip"  required>
                                    <option value="0" selected>Müşteri Tipi Seç</option>
                                    <?php foreach($musteritipleri as $musteritipi){ ?>
                                        <option value="<?php echo $musteritipi['customer_type_id']; ?>"><?php echo $musteritipi['customer_type_name']; ?></option>
                                  <?php  } ?>
                                    
                                  </select>
                                </div>
                              </div>
                              <div id="casualdate"  class="form-group">
                                <label>Sözleşme Tarihi</label>
                                <input  type="datetime-local" class="form-control" name="casual_date" >
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Ödeme Tutarı TL</label>
                                  <input type="text"  name="pay_total_tr" class="form-control" placeholder="Tutar girin.." required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Ödeme Tutarı USD</label>
                                  <input type="text"  name="pay_total_usd" class="form-control" placeholder="Tutar girin.." required/>
                                </div>
                              </div>                               
                            </div>
                            <div class="modal-footer">
                              <button type="button" id="closeinsert" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closinginsert()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>


                      

  <body>
    <?php if(!isset($_SESSION['id'])){
      header('Location: login.php');
    } ?>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'sidebar.php'; ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">

          <?php include 'navbar.php'; ?>

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              

              <div class="card">
                <?php
                  if(isset($_SESSION['success_message'])) {
                    $message = $_SESSION['success_message'];
                    unset($_SESSION['success_message']); ?>
                    <div
                        class="bs-toast toast fade show bg-success"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Başarılı Kayıt</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                    </div>
                <?php  }else if(isset($_SESSION['error_message'])){
                  $message = $_SESSION['error_message'];
                  unset($_SESSION['error_message']); ?>
                  <div
                        class="bs-toast toast fade show bg-danger"
                        role="alert"
                        aria-live="assertive"
                        aria-atomic="true"
                      >
                        <div class="toast-header">
                          <i class="bx bx-bell me-2"></i>
                          <div class="me-auto fw-semibold">Oops</div>
                          <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                          <?php echo $message; ?>
                        </div>
                  </div>

               <?php } ?>
                <h5 class="card-header">Müşterilerimiz</h5>
                <div class="row m-2">
                  <?php if($_SESSION['type']=="Admin"){ ?>
                    <div class="col-md-2">
                        <a class="btn btn-sm btn-primary text-white" data-bs-toggle="modal" data-bs-target="#Modalinsertcustomer"><i class="fa fa-plus"></i>Müşteri Ekle</a>
                    </div>
                    <?php } ?>
                    <div class="col-md-3">
                      <div class="form-group">
                        <select class="form-select btn-sm" name="customer_is_delete" id="c_is_delete" onchange="getresults(this)" required>
                          <option value="-1">Tümü</option>
                          <option value="0">Aktif</option>
                          <option value="1">Pasif</option>                                    
                        </select>
                      </div>
                    </div>
                </div>
                  
                <style type="text/css">
                  td{
                    font-size: 13px;
                  }                  
                </style>
                <div class="table-responsive text-nowrap">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Müşteri Adı</th>
                        <th>Müşteri Tipi</th>
                        <th>Sözleşme Tarihi</th>
                        <th>Ekleme Tarihi</th>
                        <th>Son Güncelleme</th>
                        <th class="text-center">Toplam Ücret TL</th>
                        <th class="text-center">Toplam Ücret USD</th>
                        <th class="text-center">İşlemler</th>
                      </tr>
                    </thead>
                    <tbody id="searchresults" class="table-border-bottom-0">
                      <?php foreach($customers as $musteri){ ?>
                        <tr>
                          <td><?php echo $musteri['customer_name']; ?></td>
                          <td><?php echo $musteri['customer_type_name']; ?></td>
                          <td><?php echo $musteri['casual_date']; ?></td>
                          <td><?php echo $musteri['customer_add_date']; ?></td>
                          <td><?php echo $musteri['customer_edit_date']; ?></td>
                          <td class="text-center" ><?php echo $musteri['pay_total_tr']; ?></td>
                          <td class="text-center" ><?php echo $musteri['pay_total_usd']; ?></td>

                          <?php if($_SESSION['type']=="Admin"){ ?>
                            <td class="text-center">
                              <a class="btn btn-sm btn-primary" data-bs-toggle="modal" style="color:white;" data-bs-target="#Modaleditcustomer" service-id="<?php echo $musteri['customer_service_id']; ?>" customer-type="<?php echo $musteri['customer_type_id']; ?>" customer-status="<?php echo $musteri['customer_is_delete']; ?>" customer-name="<?php echo $musteri['customer_name']; ?>" customer-id="<?php echo $musteri['customer_id']; ?>" onclick="get_customer(this)" id="editbuton">Düzenle<i class="bi bi-pen"></i></a>                                                         

                              <a class="btn btn-sm btn-danger" data-bs-toggle="modal" style="color:white;" data-bs-target="#Modaldeletecustomer" id="silmebutonu" customer-id="<?php echo $musteri['customer_id']; ?>"  onclick="getdata(this)">Sil<i class="bi bi-trash"></i></a>
                            </td>
                          </tr>
                            

                            

                                
                         <?php } 
                      } ?>                         
                        

                        
                      
                    </tbody>
                  </table>

              
                </div>
              </div>

              <?php 

                if($sayfasayisi > 1):
                  if(isset($_GET["sayfa"])):
                      if(is_numeric($_GET["sayfa"])):
                            $sayfa = $_GET["sayfa"];
                      else:
                            $sayfa = 1;
                      endif;
                  else:
                    $sayfa = 1;
                  endif  
                  ?>
              <div id="pagiajax">
                <div class="b-pagination-outer mt-5">
                  <ul id="border-pagination">
                    <?php 
                     if(isset($_GET["sayfa"]) && $_GET["sayfa"] > 1):
                        ?>
                         <li><a class="musteri_pagination" id="<?php echo $sayfa-1; ?>" href="javascript:;">«</a></li>
                         <?php
                         if($_GET["sayfa"] > 3):
                          ?>
                             <li><a class="musteri_pagination" href="musteriler.php?sayfa=1" >1</a></li>

                             <?php if($sayfa>4): ?>
                             <li><a href="javascript:;" >...</a></li>
                          <?php endif;
                         endif; 
                     endif;
                     for($i=$sayfa-2; $i<=$sayfa+2; $i++): 

                         if($i> 0 && $i<=$sayfasayisi):
                                if($i == $sayfa):
                                    ?>
                                   <li><a href="javascript:;" class="active"> <?php echo $i; ?></a></li>
                                <?php
                                else:
                                    ?>
                                     <li><a class="musteri_pagination" href="javascript:;" id="<?php echo $i; ?>" > <?php echo $i; ?></a></li>
                                <?php
                                endif;
                            endif;
                        
                   endfor;

                  if($sayfa < $sayfasayisi-2):
                            if($sayfa+3<$sayfasayisi):
                              ?>
                              <li><a href="javascript:;" >...</a></li>
                              <?php
                            endif;  
                            ?>
                             
                             <li><a class="musteri_pagination"  href="javascript:;" id="<?php echo $sayfasayisi; ?>" ><?php echo $sayfasayisi; ?></a></li>
                            <li><a  class="musteri_pagination"  href="javascript:;" id="<?php echo $sayfa+1; ?>">»</a></li>
                        <?php
                    else:
                          if($sayfa != $sayfasayisi):

                          ?>
                           <li><a class="musteri_pagination" href="javascript:;" id="<?php echo $sayfa+1; ?>">»</a></li><?php
                         endif;
                        endif;  

                 ?>
                  </ul> 
                </div> 
                  <?php
                endif;  
               ?>
              </div> 



          
              <!-- Layout Demo -->
              
              <!--/ Layout Demo -->
            </div>
            <!-- / Content -->

            <!-- Footer -->
            <?php include '_footer.php'; ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>

          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>

    <!-- / Layout wrapper -->



    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <div class="modal fade" id="Modaleditcustomer" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel2">Müşteri Güncelle</h5>
                              <button
                                type="button"
                                class="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div class="modal-body">
                              <form action="?pg=update" method="POST">
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Adı</label>
                                  <input type="text" id="customer_editname" name="customer_name" class="form-control" placeholder="Müşteri adı girin.." required/>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Müşteri Tipi</label>
                                  <select class="form-select" name="customer_type_id" id="updatetip"  onchange="get_service_edit(this)" required>
                                  
                                  </select>
                                </div>
                              </div>
                              <div class="row">
                                <div class="col mb-3">
                                  <label for="nameSmall" class="form-label">Status</label>
                                  <select class="form-select" name="customer_isdelete" id="customereditisdelete" required>
                                    
                                  </select>
                                </div>
                              </div>                                  
                            </div>
                            <input type="hidden" id="customer_editid" name="customer_id">
                            <div class="modal-footer">
                              <button type="button" id="closeupdate" class="btn btn-outline-secondary" data-bs-dismiss="modal" onclick="closingupdate()">
                                Close
                              </button>
                              <button type="submit" class="btn btn-primary">Kaydet</button>
                            </div>
                          </form>
                          </div>
                        </div>
                      </div>

                      <div class="modal fade" tabindex="-1" id="Modaldeletecustomer" role="dialog" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <form action="?pg=delete" method="POST">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title">Uyarı</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                                        
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <p>Silmek istediğinize emin misiniz?</p>
                                    </div>
                                    <input type="hidden" id="customer_deleteid" name="customer_id">
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" id="closing" data-dismiss="modal" onclick="closingdelete()">Vazgeç</button>
                                      <button type="submit" class="btn btn-primary">Sil</button>
                                    </div>
                                    </form>
                                  </div>
                                </div>
                            </div>

    
  </body>

  <?php
    if(isset($_GET['pg'])){
      $pg=$_GET['pg'];
      if($pg=='insert'){
        if($_POST['customer_type_id']==0){
          $_SESSION['error_message']="Müşteri tipi boş geçilemez";
          header('Location: musteriler.php');
          exit;
        }
        if($_POST['casual_date']==0){
          $_SESSION['error_message']="Sözleşme Tarihi boş geçilemez";
          header('Location: musteriler.php');
          exit;
        }
        if($_POST['pay_total_tr']=='' AND $_POST['pay_total_usd']==''){
          $_SESSION['error_message']="Ödeme tutarı boş geçilemez";
          header('Location: musteriler.php');
          exit;
        }
        $customer_name=$_POST['customer_name'];
        $customer_type_id=$_POST['customer_type_id'];
        $casual_date=$_POST['casual_date'];
        $casual_date=explode("T",$casual_date);
        $casual_date=$casual_date[0]." ".$casual_date[1];
        $pay_total_tr=$_POST['pay_total_tr'];
        $pay_total_usd=$_POST['pay_total_usd'];
        $values=$_POST;
        $db=new crud();
        $control=$db->wreadcount("customers","customer_name",$customer_name);
        if($control){
          $_SESSION['error_message']="Böyle bir müşterimiz zaten var";
          header('Location: musteriler.php');
          exit();
        }
        $sonuc=$db->insertcustomer($customer_name,$customer_type_id,$casual_date,$pay_total_tr,$pay_total_usd);
        if($sonuc['status']){
          $_SESSION['success_message']="Müşteri başarıyla kaydedildi.";
          $values+=['casual' => $casual_date];
          ############################################################################################
          $log_summary = [
              'post' => $values,
          ];
          $user_log = (object) [
              'user_id'  => $_SESSION['id'],
              'company_id'=> $sonuc['id'],
              'type'     => 'A',
              'method'   => 'POST',
              'title'    => 'Müşteri Ekleme',
              'response' => 'ok',
              'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
              'ip'       => $_SERVER['REMOTE_ADDR']
          ];        
          $db->log($user_log);
          ############################################################################################
          header('Location: musteriler.php');
          exit();
        }
        else{
          $_SESSION['error_message']="Kayıt başarısız";
          header('Location: musteriler.php');
          exit();
        }
      }
      else if($pg=='update'){
        $customer_name=$_POST['customer_name'];
        $customer_type_id=$_POST['customer_type_id'];
        $customer_isdelete=$_POST['customer_isdelete'];
        $customer_id=$_POST['customer_id'];
        $db=new crud();
        $ctype=$db->wread("customer_types","customer_type_id",$customer_type_id);
        foreach($ctype as $data){
          $ctypename=$data['customer_type_name'];
        }
        $values=$_POST;
        $sonuc=$db->updatecustomer($customer_name,$customer_type_id,$customer_isdelete,$customer_id);
        if($sonuc['status']){
          $_SESSION['success_message']="Müşteri başarıyla güncellendi.";
          $ucustomer=$db->wread("customers","customer_id",$customer_id);
          foreach($ucostomer as $veri){
            $values+=['edit_date' =>$veri['customer_edit_date']];
          }
          ///////////////////////
                $values+=['customer_type_name' =>$ctypename];
                $log_summary = [
                    'post' => $values,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> $sonuc['id'],
                    'type'     => 'U',
                    'method'   => 'PUT',
                    'title'    => 'Müşteri güncelleme',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $db->log($user_log);
                /////////////////////////
          header('Location: musteriler.php');
        }
        else{
          $_SESSION['error_message']="Güncelleme başarısız";
          header('Location: musteriler.php');
        }
      }
      else if($pg='delete'){
        $id=$_POST['customer_id'];
        $values=$_POST;
        $db=new crud();
        $customer=$db->wread("customers","customer_id",$id);
        foreach($customer as $item){
          $customer_name=$item['customer_name'];
        }
        $sonuc=$db->updatestatus("customers","customer_id","customer_is_delete",$id);
        if($sonuc['status']){
          $_SESSION['success_message']=" Müşteri başarıyla silindi.";
          $today=getdate();
          $tarih=$today['year']."-".$today['mon']."-".$today['mday']." ".$today['hours'].":".$today['minutes'].":".$today['seconds'];
          $values+=['customer_name' => $customer_name,'silinme_tarihi' => $tarih];
          $log_summary = [
                    'post' => $values,
                ];
                $user_log = (object) [
                    'user_id'  => $_SESSION['id'],
                    'company_id'=> $id,
                    'type'     => 'D',
                    'method'   => 'DELETE',
                    'title'    => 'Müşteri SİLME',
                    'response' => 'ok',
                    'summary'  => json_encode($log_summary, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    'ip'       => $_SERVER['REMOTE_ADDR']
                ];        
                $db->log($user_log);
          header('Location: musteriler.php');
        }
        else{
          $_SESSION['error_message']="Silme başarısız";
          header('Location: musteriler.php');
        }
      }
    }



  ?>

</html>
<script src="assets/js/main.js"></script>
<script src="assets/js/ui-toasts.js"></script>

<script>

function closinginsert(){
  $('#Modalinsertcustomer').modal('toggle');
}
function closingupdate(){
  $('#Modaleditcustomer').modal('toggle');
}
function closingdelete(){
  $('#Modaldeletecustomer').modal('toggle');
}

function get_customer(attr){
  var customer_type = $(attr).attr('customer-type');
  console.log(customer_type);
  var customer_name= $(attr).attr('customer-name');
  var customer_id= $(attr).attr('customer-id');
  var customer_serviceid= $(attr).attr('service-id');
  var customer_isdelete= $(attr).attr('customer-status');
  $('#customer_editid').val(customer_id);
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{customer_edittype:customer_type, customer_editname:customer_name, customer_serviceid:customer_serviceid, customer_isdelete:customer_isdelete},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      console.log(myArray[0]);
      $('#customer_editname').val(myArray[0]);
      $('#updatetip').html(myArray[1]);
      $('#updateserviceid').html(myArray[2]);
      $('#customereditisdelete').html(myArray[3]);
    }
  });
}
$(document).on('click', '.musteri_pagination', function(){
        var page = $(this).attr("id");
    });


function get_service_edit(attr){
  var customer_typeforservice = $('#updatetip').val();
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{customer_typeforservice:customer_typeforservice},
    dataType: 'html',
    success: function(datam){
      $('#updateserviceid').html(datam);
    }
  });
}
function getdata(attr){
  var customer_id=$(attr).attr('customer-id');
  $('#customer_deleteid').val(customer_id);

}

function getresults(page=1){
  var c_is_delete=$('#c_is_delete').val();
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{c_is_delete:c_is_delete, page:page},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#searchresults').html(myArray[0]);
      $('#pagiajax').html(myArray[1]);
    }
  });
}

$(document).on('click', '.musteri_pagination', function(){
        var page = $(this).attr("id");
        getresults(page)
    });


function pagination(attr){
  var page=$(attr).attr('page-id');
  var c_is_delete=$('#c_is_delete').val();
  $.ajax({
    method:'post',
    url: 'ajax.php',
    data:{c_is_delete:c_is_delete, page:page},
    dataType: 'html',
    success: function(datam){
      const myArray = datam.split("*");
      $('#searchresults').html(myArray[0]);
      $('#pagiajax').html(myArray[1]);
    }
  });
}
</script>



